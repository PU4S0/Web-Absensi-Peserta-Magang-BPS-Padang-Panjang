<?php
session_start();
require_once 'includes/db.php';

$error = "";

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = trim($_POST['username']);
    $password = $_POST['password'];

    $stmt = $conn->prepare("SELECT id, nama, password FROM peserta WHERE username = ?");
    $stmt->bind_param("s", $username);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($row = $result->fetch_assoc()) {
        if (password_verify($password, $row['password'])) {
            $_SESSION['peserta_id'] = $row['id'];
            $_SESSION['peserta_nama'] = $row['nama'];
            header("Location: dashboard_peserta.php");
            exit;
        } else {
            $error = "Password salah.";
        }
    } else {
        $error = "Username tidak ditemukan.";
    }
    $stmt->close();
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Login Peserta Magang</title>
    <link rel="stylesheet" href="assets/css/style.css?v=10">
</head>
<body>
    <div class="page-center">
    <div class="auth-box">
        <img src="assets/img/logo_bps.png?v=2" alt="Logo BPS" class="form-logo">
        <h2>Login Peserta Magang</h2>
        <?php if ($error): ?>
            <script>document.addEventListener('DOMContentLoaded', function(){ tampilkanPopup(<?= json_encode($error) ?>, 'error'); });</script>
        <?php endif; ?>
        <form method="POST">
            <label>Username</label>
            <input type="text" name="username" required>
            <label>Password</label>
            <input type="password" name="password" required>
            <button type="submit" class="btn-primary">Masuk</button>
        </form>
        <p class="muted">
            <a href="signup.php">Daftar sebagai peserta baru</a> &middot;
            <a href="admin_login.php">Login Admin</a>
        </p>
        <p class="muted">Lupa password? Hubungi admin untuk direset.</p>
        <p class="muted"><a href="index.php">&larr; Kembali ke Beranda</a></p>
    </div>
    </div>
    <?php require 'includes/footer.php'; ?>
</body>
</html>

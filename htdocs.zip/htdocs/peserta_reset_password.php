<?php
require_once 'includes/auth.php';
require_once 'includes/db.php';
require_admin_login();

if (!isset($_GET['id'])) {
    header("Location: peserta_admin.php");
    exit;
}
$id = (int)$_GET['id'];

$stmt = $conn->prepare("SELECT nama FROM peserta WHERE id = ?");
$stmt->bind_param("i", $id);
$stmt->execute();
$result = $stmt->get_result();
if ($result->num_rows === 0) {
    header("Location: peserta_admin.php");
    exit;
}
$peserta = $result->fetch_assoc();
$stmt->close();

$error = "";
$success = "";

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $password_baru = $_POST['password_baru'];
    $konfirmasi = $_POST['konfirmasi_password'];

    if (strlen($password_baru) < 6) {
        $error = "Password minimal 6 karakter.";
    } elseif ($password_baru !== $konfirmasi) {
        $error = "Konfirmasi password tidak sama.";
    } else {
        $hashed = password_hash($password_baru, PASSWORD_DEFAULT);
        $stmt = $conn->prepare("UPDATE peserta SET password = ? WHERE id = ?");
        $stmt->bind_param("si", $hashed, $id);
        $stmt->execute();
        $stmt->close();
        header("Location: peserta_admin.php?msg=" . urlencode("Password " . $peserta['nama'] . " berhasil direset."));
        exit;
    }
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Reset Password Peserta</title>
    <link rel="stylesheet" href="assets/css/style.css?v=10">
</head>
<body>
    <div class="page-center">
    <div class="auth-box">
        <img src="assets/img/logo_bps.png?v=2" alt="Logo BPS" class="form-logo">
        <h2>Reset Password</h2>
        <p class="muted" style="margin-top:-8px;">Peserta: <strong><?= htmlspecialchars($peserta['nama']) ?></strong></p>

        <?php if ($error): ?>
            <script>document.addEventListener('DOMContentLoaded', function(){ tampilkanPopup(<?= json_encode($error) ?>, 'error'); });</script>
        <?php endif; ?>

        <form method="POST">
            <label>Password Baru</label>
            <input type="password" name="password_baru" required>
            <label>Konfirmasi Password Baru</label>
            <input type="password" name="konfirmasi_password" required>
            <button type="submit" class="btn-primary">Reset Password</button>
        </form>
        <p class="muted"><a href="peserta_admin.php">&larr; Kembali ke Daftar Peserta</a></p>
    </div>
    </div>
    <?php require 'includes/footer.php'; ?>
</body>
</html>

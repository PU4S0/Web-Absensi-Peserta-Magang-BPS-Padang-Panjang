<?php
require_once 'includes/auth.php';
require_once 'includes/db.php';
require_once 'includes/upload_helper.php';
require_admin_login();

if ($_SERVER['REQUEST_METHOD'] === 'POST' && !empty($_POST['ids']) && is_array($_POST['ids'])) {
    $ids = array_filter(array_map('intval', $_POST['ids']));
    if (!empty($ids)) {
        $placeholders = implode(',', array_fill(0, count($ids), '?'));
        $types = str_repeat('i', count($ids));

        // Hapus file foto profil dulu sebelum record-nya hilang
        $stmt = $conn->prepare("SELECT foto FROM peserta WHERE id IN ($placeholders)");
        $stmt->bind_param($types, ...$ids);
        $stmt->execute();
        $res = $stmt->get_result();
        while ($p = $res->fetch_assoc()) hapus_foto_profil($p['foto']);
        $stmt->close();

        // Riwayat absensi & pengajuan ikut terhapus otomatis lewat ON DELETE CASCADE
        $stmt = $conn->prepare("DELETE FROM peserta WHERE id IN ($placeholders)");
        $stmt->bind_param($types, ...$ids);
        $stmt->execute();
        $jumlah = $stmt->affected_rows;
        $stmt->close();

        header("Location: peserta_admin.php?msg=" . urlencode("$jumlah peserta berhasil dihapus."));
        exit;
    }
}

header("Location: peserta_admin.php");
exit;

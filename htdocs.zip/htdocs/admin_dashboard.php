<?php
require_once 'includes/auth.php';
require_once 'includes/db.php';
require_once 'includes/config.php';
require_admin_login();

$jumlah_notif = jumlah_pengajuan_menunggu($conn);

// ---- Rekap data peserta magang ----
$peserta_list = $conn->query("SELECT * FROM peserta ORDER BY nama ASC");

// ---- Rekap absen harian (dengan filter tanggal) ----
$tanggal_filter = $_GET['tanggal'] ?? date('Y-m-d');

$stmt = $conn->prepare("
    SELECT p.nama, a.jam_masuk, a.jam_pulang, a.status, a.keterangan, p.tanggal_mulai, p.tanggal_selesai
    FROM peserta p
    LEFT JOIN absensi a ON a.peserta_id = p.id AND a.tanggal = ?
    ORDER BY p.nama ASC
");
$stmt->bind_param("s", $tanggal_filter);
$stmt->execute();
$data_harian = $stmt->get_result();
$stmt->close();
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Dashboard Admin</title>
    <link rel="stylesheet" href="https://cdn.datatables.net/2.1.8/css/dataTables.dataTables.min.css">
    <link rel="stylesheet" href="assets/css/style.css?v=10">
</head>
<body>
    <div class="container container-wide">
        <div class="topbar">
            <div class="topbar-left">
                <img src="assets/img/logo_bps.png?v=2" alt="Logo BPS" class="topbar-logo">
                <h2>Dashboard Admin</h2>
            </div>
            <div class="topbar-actions">
                <a href="admin_notifikasi.php" class="btn-outline notif-bell">
                    &#128276; Notifikasi
                    <?php if ($jumlah_notif > 0): ?><span class="notif-badge"><?= $jumlah_notif ?></span><?php endif; ?>
                </a>
                <a href="ganti_password_admin.php" class="btn-outline">Ganti Password</a>
                <a href="logout.php" class="btn-outline">Logout</a>
            </div>
        </div>

        <div class="card">
            <div class="card-header-row">
                <h3>Rekap Data Peserta Magang</h3>
                <a href="peserta_admin.php" class="btn-outline">Kelola Peserta &rarr;</a>
            </div>

            <div class="dt-filter-bar">
                <div class="dt-filter-item">
                    <label>Cari Nama</label>
                    <input type="text" id="filter-nama-peserta" placeholder="Ketik nama...">
                </div>
                <div class="dt-filter-item">
                    <label>Status Magang</label>
                    <select id="filter-status-peserta">
                        <option value="">Semua</option>
                        <option value="Aktif">Aktif</option>
                        <option value="Tidak Aktif">Tidak Aktif</option>
                    </select>
                </div>
                <div class="dt-filter-item">
                    <label>Mulai Dari</label>
                    <input type="date" id="filter-mulai-dari">
                </div>
                <div class="dt-filter-item">
                    <label>Sampai</label>
                    <input type="date" id="filter-mulai-sampai">
                </div>
            </div>

            <table id="tabel-peserta" class="display">
                <thead>
                <tr>
                    <th>Nama</th><th>Asal Universitas</th><th>Mulai</th><th>Selesai</th><th>Status</th><th class="dt-hidden">MulaiISO</th>
                </tr>
                </thead>
                <tbody>
                <?php while ($p = $peserta_list->fetch_assoc()): $st = status_peserta($p['tanggal_selesai']); ?>
                <tr>
                    <td><?= htmlspecialchars($p['nama']) ?></td>
                    <td><?= htmlspecialchars($p['asal_universitas']) ?></td>
                    <td><?= date('d M Y', strtotime($p['tanggal_mulai'])) ?></td>
                    <td><?= date('d M Y', strtotime($p['tanggal_selesai'])) ?></td>
                    <td><span class="badge <?= $st === 'Aktif' ? 'badge-aktif' : 'badge-tidak-aktif' ?>"><?= $st ?></span></td>
                    <td><?= $p['tanggal_mulai'] ?></td>
                </tr>
                <?php endwhile; ?>
                </tbody>
            </table>
        </div>

        <div class="card">
            <div class="card-header-row">
                <h3>Rekap Absen Harian</h3>
                <a href="rekap_bulanan.php" class="btn-outline">Lihat Rekap Bulanan &rarr;</a>
            </div>

            <form method="GET" class="filter-row">
                <label>Tanggal:</label>
                <input type="date" name="tanggal" value="<?= htmlspecialchars($tanggal_filter) ?>">
                <button type="submit" class="btn-primary">Tampilkan</button>
                <a href="export_harian.php?tanggal=<?= htmlspecialchars($tanggal_filter) ?>" class="btn-outline">Download Excel</a>
            </form>

            <table id="tabel-harian" class="display">
                <thead>
                <tr>
                    <th>Nama</th><th>Jam Datang</th><th>Jam Pulang</th><th>Kehadiran</th><th>Status Magang</th>
                </tr>
                </thead>
                <tbody>
                <?php while ($row = $data_harian->fetch_assoc()): $st = status_peserta($row['tanggal_selesai']); ?>
                <tr>
                    <td><?= htmlspecialchars($row['nama']) ?></td>
                    <td><?= $row['jam_masuk'] ?? '-' ?></td>
                    <td><?= $row['jam_pulang'] ?? '-' ?></td>
                    <td>
                        <?php if ($row['status']): ?>
                            <span class="status-pill status-<?= $row['status'] ?>"><?= ucfirst($row['status']) ?></span>
                            <?php if ($row['keterangan']): ?><br><span class="muted-inline"><?= htmlspecialchars($row['keterangan']) ?></span><?php endif; ?>
                        <?php else: ?>
                            <?php if (tidak_hadir_hari_ini($tanggal_filter, $row['tanggal_mulai'], $row['tanggal_selesai'])): ?>
                                <span class="status-pill status-tidak-hadir">Tidak Hadir</span>
                            <?php else: ?>
                                <span class="status-pill status-belum">Belum Absen</span>
                            <?php endif; ?>
                        <?php endif; ?>
                    </td>
                    <td><span class="badge <?= $st === 'Aktif' ? 'badge-aktif' : 'badge-tidak-aktif' ?>"><?= $st ?></span></td>
                </tr>
                <?php endwhile; ?>
                </tbody>
            </table>
        </div>
    </div>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
    <script src="https://cdn.datatables.net/2.1.8/js/dataTables.min.js"></script>
    <script>
        $(document).ready(function () {
            const tabelPeserta = $('#tabel-peserta').DataTable({
                order: [[0, 'asc']],
                pageLength: 10,
                columnDefs: [{ targets: 5, visible: false }]
            });

            // Filter nama (kolom 0)
            $('#filter-nama-peserta').on('keyup', function () {
                tabelPeserta.column(0).search(this.value).draw();
            });

            // Filter status (kolom 4, exact match)
            $('#filter-status-peserta').on('change', function () {
                const val = this.value;
                tabelPeserta.column(4).search(val ? '^' + val + '$' : '', true, false).draw();
            });

            // Filter rentang tanggal mulai (pakai kolom tersembunyi ISO di index 5)
            $.fn.dataTable.ext.search.push(function (settings, data) {
                if (settings.nTable.id !== 'tabel-peserta') return true;
                const dari = $('#filter-mulai-dari').val();
                const sampai = $('#filter-mulai-sampai').val();
                const tgl = data[5]; // format YYYY-MM-DD dari kolom tersembunyi
                if (dari && tgl < dari) return false;
                if (sampai && tgl > sampai) return false;
                return true;
            });
            $('#filter-mulai-dari, #filter-mulai-sampai').on('change', function () {
                tabelPeserta.draw();
            });

            $('#tabel-harian').DataTable({ order: [[0, 'asc']], pageLength: 10 });
        });
    </script>
    <?php require 'includes/footer.php'; ?>
</body>
</html>

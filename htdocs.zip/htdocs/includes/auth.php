<?php
session_start();

// Panggil di halaman yang hanya boleh diakses peserta yang sudah login
function require_peserta_login() {
    if (!isset($_SESSION['peserta_id'])) {
        header("Location: login.php");
        exit;
    }
}

// Panggil di halaman yang hanya boleh diakses admin
function require_admin_login() {
    if (!isset($_SESSION['admin_id'])) {
        header("Location: admin_login.php");
        exit;
    }
}

<link rel="stylesheet" href="assets/css/style.css?v=12">
<footer class="site-footer">
    <span>Copyright &copy; <?= date('Y') ?> pu4s0. All Right Reserved.</span>
</footer>

<!-- ===== Komponen popup, dipakai di semua halaman ===== -->
<div id="popup-overlay" class="popup-overlay" style="display:none;">
    <div class="popup-box">
        <div id="popup-icon" class="popup-icon">!</div>
        <p id="popup-pesan" class="popup-pesan"></p>
        <button type="button" class="btn-primary" onclick="tutupPopup()">OK</button>
    </div>
</div>
<script>
    function tampilkanPopup(pesan, tipe) {
        tipe = tipe || 'error';
        const overlay = document.getElementById('popup-overlay');
        const icon = document.getElementById('popup-icon');
        const box = overlay.querySelector('.popup-box');
        document.getElementById('popup-pesan').textContent = pesan;
        box.classList.remove('popup-box-error', 'popup-box-success');
        box.classList.add(tipe === 'success' ? 'popup-box-success' : 'popup-box-error');
        icon.textContent = tipe === 'success' ? '\u2713' : '!';
        overlay.style.display = 'flex';
    }
    function tutupPopup() {
        document.getElementById('popup-overlay').style.display = 'none';
    }
    document.addEventListener('DOMContentLoaded', function () {
        const overlay = document.getElementById('popup-overlay');
        if (overlay) {
            overlay.addEventListener('click', function (e) {
                if (e.target === overlay) tutupPopup();
            });
        }
    });
</script>

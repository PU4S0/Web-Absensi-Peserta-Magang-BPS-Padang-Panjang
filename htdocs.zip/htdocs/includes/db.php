<?php
date_default_timezone_set('Asia/Jakarta');

// ISI dengan data dari menu MySQL Databases InfinityFree
$host = "sql107.infinityfree.com";
$db_user = "if0_43222271";
$db_pass = "F2i9o5kqJMHoO";
$db_name = "if0_43222271_database_hosting";

mysqli_report(MYSQLI_REPORT_OFF);
$conn = @new mysqli($host, $db_user, $db_pass, $db_name);

if ($conn->connect_error) {
    die("Koneksi database gagal: " . $conn->connect_error);
}

$conn->set_charset("utf8mb4");

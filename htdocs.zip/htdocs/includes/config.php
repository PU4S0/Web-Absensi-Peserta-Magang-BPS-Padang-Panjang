<?php
// =====================================================
// KONFIGURASI LOKASI KANTOR
// =====================================================
// PENTING: koordinat di bawah masih PERKIRAAN untuk area
// Kota Padang Panjang. Ganti dengan koordinat presisi kantor:
// 1. Buka Google Maps, cari "BPS Kota Padang Panjang"
//    (Jl. Sutan Syahrir No. 2, Silaing Bawah)
// 2. Klik kanan tepat di titik gedung kantor -> koordinat
//    akan muncul di bagian atas, contoh: -0.461234, 100.398765
// 3. Ganti nilai KANTOR_LAT dan KANTOR_LNG di bawah ini

define('KANTOR_LAT', -0.465813);
define('KANTOR_LNG', 100.383373);
define('RADIUS_METER', 50); // radius maksimal absen dari kantor

// Hitung jarak antara 2 koordinat (meter) pakai formula Haversine
function hitung_jarak_meter($lat1, $lng1, $lat2, $lng2) {
    $earth_radius = 6371000; // meter

    $lat1_rad = deg2rad($lat1);
    $lat2_rad = deg2rad($lat2);
    $delta_lat = deg2rad($lat2 - $lat1);
    $delta_lng = deg2rad($lng2 - $lng1);

    $a = sin($delta_lat / 2) * sin($delta_lat / 2) +
         cos($lat1_rad) * cos($lat2_rad) *
         sin($delta_lng / 2) * sin($delta_lng / 2);
    $c = 2 * atan2(sqrt($a), sqrt(1 - $a));

    return $earth_radius * $c;
}

// Hitung status aktif/tidak peserta berdasarkan tanggal_selesai
function status_peserta($tanggal_selesai) {
    return (strtotime($tanggal_selesai) >= strtotime(date('Y-m-d'))) ? 'Aktif' : 'Tidak Aktif';
}

// =====================================================
// KOP SURAT & TANDA TANGAN untuk export Excel
// =====================================================
// Ganti nama & NIP di bawah ini sesuai pejabat yang berwenang menandatangani
define('INSTANSI_NAMA', 'BADAN PUSAT STATISTIK KOTA PADANG PANJANG');
define('INSTANSI_ALAMAT', 'Jl. Sutan Syahrir No. 2, Silaing Bawah, Padang Panjang Barat, Kota Padang Panjang, Sumatera Barat 27118');

define('PIMPINAN_JABATAN', 'Kepala BPS Kota Padang Panjang');
define('PIMPINAN_NAMA', '__________________________'); // ganti dengan nama pimpinan
define('PIMPINAN_NIP', '__________________________');  // ganti dengan NIP pimpinan

define('PENANGGUNG_JAWAB_JABATAN', 'Kasubag Umum');
define('PENANGGUNG_JAWAB_NAMA', 'Aulia Rahman S.E, M.Si');
define('PENANGGUNG_JAWAB_NIP', '198610062006041008');

// Hitung jumlah pengajuan yang masih menunggu persetujuan (untuk badge notifikasi admin)
function jumlah_pengajuan_menunggu($conn) {
    $result = $conn->query("SELECT COUNT(*) AS jumlah FROM pengajuan WHERE status_pengajuan = 'menunggu'");
    return (int) $result->fetch_assoc()['jumlah'];
}

// Nama hari dalam bahasa Indonesia (PHP date('N') = 1 Senin ... 7 Minggu)
function strftime_id($nomor_hari) {
    $hari = [1 => 'Senin', 2 => 'Selasa', 3 => 'Rabu', 4 => 'Kamis', 5 => 'Jumat', 6 => 'Sabtu', 7 => 'Minggu'];
    return $hari[(int)$nomor_hari] ?? '';
}

// Ubah tanggal (format PHP date('d F Y')) jadi nama bulan Indonesia, contoh: "05 February 2023" -> "05 Februari 2023"
function tanggal_indonesia($timestamp) {
    $bulan_en = ['January','February','March','April','May','June','July','August','September','October','November','December'];
    $bulan_id = ['Januari','Februari','Maret','April','Mei','Juni','Juli','Agustus','September','Oktober','November','Desember'];
    return str_replace($bulan_en, $bulan_id, date('d F Y', $timestamp));
}

// =====================================================
// Helper status "Tidak Hadir" otomatis
// =====================================================
// Ambil semua tanggal hari kerja (Senin-Jumat) antara $mulai dan $selesai (inklusif)
function tanggal_hari_kerja($mulai, $selesai) {
    $hasil = [];
    $cur = strtotime($mulai);
    $akhir = strtotime($selesai);
    while ($cur <= $akhir) {
        if ((int) date('N', $cur) <= 5) { // 1-5 = Senin-Jumat
            $hasil[] = date('Y-m-d', $cur);
        }
        $cur = strtotime('+1 day', $cur);
    }
    return $hasil;
}

// Cari tanggal-tanggal yang seharusnya peserta hadir (hari kerja, dalam masa magangnya,
// dan sudah lewat/kemarin atau sebelumnya) tapi TIDAK ADA record absensi sama sekali
// (bukan hadir/izin/sakit). Dipakai buat status "Tidak Hadir" otomatis.
function tanggal_tidak_hadir($conn, $peserta_id, $tgl_mulai_magang, $tgl_selesai_magang, $dari, $sampai) {
    $batas_akhir = min(strtotime($sampai), strtotime($tgl_selesai_magang), strtotime('yesterday'));
    $batas_awal = max(strtotime($dari), strtotime($tgl_mulai_magang));
    if ($batas_awal > $batas_akhir) return [];

    $kandidat = tanggal_hari_kerja(date('Y-m-d', $batas_awal), date('Y-m-d', $batas_akhir));
    if (empty($kandidat)) return [];

    $dari_s = date('Y-m-d', $batas_awal);
    $sampai_s = date('Y-m-d', $batas_akhir);
    $stmt = $conn->prepare("SELECT tanggal FROM absensi WHERE peserta_id = ? AND tanggal BETWEEN ? AND ?");
    $stmt->bind_param("iss", $peserta_id, $dari_s, $sampai_s);
    $stmt->execute();
    $res = $stmt->get_result();
    $ada_record = [];
    while ($row = $res->fetch_assoc()) {
        $ada_record[$row['tanggal']] = true;
    }
    $stmt->close();

    return array_values(array_diff($kandidat, array_keys($ada_record)));
}

// Cek apakah tanggal tertentu (tanpa record absensi) dihitung "Tidak Hadir":
// hari kerja, sudah lewat (sebelum hari ini), dan masih dalam masa magang peserta.
function tidak_hadir_hari_ini($tanggal, $tgl_mulai_magang, $tgl_selesai_magang) {
    $t = strtotime($tanggal);
    return $t < strtotime('today')
        && (int) date('N', $t) <= 5
        && $t >= strtotime($tgl_mulai_magang)
        && $t <= strtotime($tgl_selesai_magang);
}

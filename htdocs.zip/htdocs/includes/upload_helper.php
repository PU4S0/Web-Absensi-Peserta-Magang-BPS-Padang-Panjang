<?php
// =====================================================
// Helper upload foto profil peserta
// =====================================================
function proses_upload_foto_profil($nama_field_input, $wajib = false) {
    $folder = __DIR__ . '/../assets/uploads/peserta/';
    $tipe_diizinkan = ['image/jpeg' => 'jpg', 'image/png' => 'png', 'image/webp' => 'webp'];
    $maks_ukuran = 2 * 1024 * 1024; // 2MB

    if (!isset($_FILES[$nama_field_input]) || $_FILES[$nama_field_input]['error'] === UPLOAD_ERR_NO_FILE) {
        if ($wajib) {
            return ['ok' => false, 'error' => 'Foto profil wajib diupload.'];
        }
        return ['ok' => true, 'filename' => null];
    }

    $file = $_FILES[$nama_field_input];

    if ($file['error'] !== UPLOAD_ERR_OK) {
        return ['ok' => false, 'error' => 'Gagal upload foto, coba lagi.'];
    }
    if ($file['size'] > $maks_ukuran) {
        return ['ok' => false, 'error' => 'Ukuran foto maksimal 2MB.'];
    }

    $finfo = finfo_open(FILEINFO_MIME_TYPE);
    $mime = finfo_file($finfo, $file['tmp_name']);
    finfo_close($finfo);

    if (!isset($tipe_diizinkan[$mime])) {
        return ['ok' => false, 'error' => 'Format foto harus JPG, PNG, atau WEBP.'];
    }

    $ekstensi = $tipe_diizinkan[$mime];
    $nama_file = 'peserta_' . uniqid() . '.' . $ekstensi;

    if (!is_dir($folder)) {
        mkdir($folder, 0755, true);
    }

    if (!move_uploaded_file($file['tmp_name'], $folder . $nama_file)) {
        return ['ok' => false, 'error' => 'Gagal menyimpan foto ke server.'];
    }

    return ['ok' => true, 'filename' => $nama_file];
}

function hapus_foto_profil($nama_file) {
    if (!$nama_file) return;
    $path = __DIR__ . '/../assets/uploads/peserta/' . $nama_file;
    if (file_exists($path)) {
        @unlink($path);
    }
}

function url_foto_profil($nama_file) {
    if (!$nama_file) return null;
    $path = __DIR__ . '/../assets/uploads/peserta/' . $nama_file;
    if (!file_exists($path)) return null;
    return 'assets/uploads/peserta/' . $nama_file;
}

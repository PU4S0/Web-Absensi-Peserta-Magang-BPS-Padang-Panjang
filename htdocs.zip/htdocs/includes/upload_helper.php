<?php
// =====================================================
// Helper upload foto profil peserta
// =====================================================
function proses_upload_foto_profil($nama_field_input, $wajib = false) {
    $folder = __DIR__ . '/../assets/uploads/peserta/';
    $tipe_diizinkan = ['image/jpeg' => 'jpg', 'image/png' => 'png', 'image/webp' => 'webp'];
    $maks_ukuran = 25 * 1024 * 1024; // batas longgar 25MB; foto otomatis dikecilkan setelah diupload

    if (!isset($_FILES[$nama_field_input]) || $_FILES[$nama_field_input]['error'] === UPLOAD_ERR_NO_FILE) {
        if ($wajib) {
            return ['ok' => false, 'error' => 'Foto profil wajib diupload.'];
        }
        return ['ok' => true, 'filename' => null];
    }

    $file = $_FILES[$nama_field_input];

    if ($file['error'] === UPLOAD_ERR_INI_SIZE || $file['error'] === UPLOAD_ERR_FORM_SIZE) {
        return ['ok' => false, 'error' => 'Ukuran foto terlalu besar untuk server. Coba foto lain atau kecilkan dulu.'];
    }
    if ($file['error'] !== UPLOAD_ERR_OK) {
        return ['ok' => false, 'error' => 'Gagal upload foto, coba lagi.'];
    }
    if ($file['size'] > $maks_ukuran) {
        return ['ok' => false, 'error' => 'Ukuran foto terlalu besar (maksimal 25MB).'];
    }

    $finfo = finfo_open(FILEINFO_MIME_TYPE);
    $mime = finfo_file($finfo, $file['tmp_name']);
    finfo_close($finfo);

    if (!isset($tipe_diizinkan[$mime])) {
        return ['ok' => false, 'error' => 'Format foto harus JPG, PNG, atau WEBP.'];
    }

    if (!is_dir($folder)) {
        mkdir($folder, 0755, true);
    }

    // Kecilkan otomatis (maks. 800px sisi terpanjang, JPEG) supaya foto besar dari HP tetap bisa dipakai
    $hasil_kecil = kecilkan_foto($file['tmp_name'], $mime, $folder);
    if ($hasil_kecil !== null) {
        return ['ok' => true, 'filename' => $hasil_kecil];
    }

    // Fallback kalau ekstensi GD tidak tersedia: simpan apa adanya
    $nama_file = 'peserta_' . uniqid() . '.' . $tipe_diizinkan[$mime];
    if (!move_uploaded_file($file['tmp_name'], $folder . $nama_file)) {
        return ['ok' => false, 'error' => 'Gagal menyimpan foto ke server.'];
    }

    return ['ok' => true, 'filename' => $nama_file];
}

function hapus_foto_profil($nama_file) {
    if (!$nama_file) return;
    $path = __DIR__ . '/../assets/uploads/peserta/' . $nama_file;
    if (file_exists($path)) {
        @unlink($path);
    }
}

function url_foto_profil($nama_file) {
    if (!$nama_file) return null;
    $path = __DIR__ . '/../assets/uploads/peserta/' . $nama_file;
    if (!file_exists($path)) return null;
    return 'assets/uploads/peserta/' . $nama_file;
}


// Perkecil foto jadi maks. 800px dan simpan sebagai JPEG. Return nama file, atau null kalau gagal / GD tidak ada.
function kecilkan_foto($tmp_path, $mime, $folder) {
    if (!function_exists('imagecreatetruecolor')) return null;

    @ini_set('memory_limit', '256M');

    if ($mime === 'image/jpeg' && function_exists('imagecreatefromjpeg')) {
        $img = @imagecreatefromjpeg($tmp_path);
    } elseif ($mime === 'image/png' && function_exists('imagecreatefrompng')) {
        $img = @imagecreatefrompng($tmp_path);
    } elseif ($mime === 'image/webp' && function_exists('imagecreatefromwebp')) {
        $img = @imagecreatefromwebp($tmp_path);
    } else {
        return null;
    }
    if (!$img) return null;

    // Putar sesuai orientasi EXIF (foto dari HP sering tersimpan miring)
    if ($mime === 'image/jpeg' && function_exists('exif_read_data')) {
        $exif = @exif_read_data($tmp_path);
        $orientasi = $exif['Orientation'] ?? 1;
        if ($orientasi == 3) $img = imagerotate($img, 180, 0);
        elseif ($orientasi == 6) $img = imagerotate($img, -90, 0);
        elseif ($orientasi == 8) $img = imagerotate($img, 90, 0);
    }

    $w = imagesx($img);
    $h = imagesy($img);
    $maks = 800;
    $skala = min(1, $maks / max($w, $h));
    $w_baru = max(1, (int)round($w * $skala));
    $h_baru = max(1, (int)round($h * $skala));

    $baru = imagecreatetruecolor($w_baru, $h_baru);
    imagefill($baru, 0, 0, imagecolorallocate($baru, 255, 255, 255)); // latar putih untuk PNG transparan
    imagecopyresampled($baru, $img, 0, 0, 0, 0, $w_baru, $h_baru, $w, $h);

    $nama_file = 'peserta_' . uniqid() . '.jpg';
    $ok = imagejpeg($baru, $folder . $nama_file, 85);
    imagedestroy($img);
    imagedestroy($baru);

    return $ok ? $nama_file : null;
}

<?php
// =====================================================
// Helper untuk file export Excel (.xls berbasis HTML)
// =====================================================

function logo_url_absolut() {
    $protokol = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') ? 'https' : 'http';
    $host = $_SERVER['HTTP_HOST'] ?? 'localhost';
    $folder = rtrim(str_replace('\\', '/', dirname($_SERVER['SCRIPT_NAME'])), '/');
    return $protokol . '://' . $host . $folder . '/assets/img/logo_bps.png?v=2';
}

// Pembuka dokumen: set halaman cetak ke LANDSCAPE A4 secara otomatis lewat CSS
// khusus Excel (mso-page-orientation), supaya tabel lebar tidak kepotong pas di-print.
function buka_dokumen_excel() {
    ob_start();
    ?>
<html xmlns:o="urn:schemas-microsoft-com:office:office" xmlns:x="urn:schemas-microsoft-com:office:excel">
<head>
<style>
    @page Section1 {
        size: 841.9pt 595.3pt; /* A4 landscape */
        mso-page-orientation: landscape;
        margin: 40pt 30pt 40pt 30pt;
    }
    div.Section1 { page: Section1; }
    table { font-family: Arial, sans-serif; }
</style>
</head>
<body>
<div class="Section1">
    <?php
    return ob_get_clean();
}

function tutup_dokumen_excel() {
    return "</div></body></html>";
}

// Kop surat. $jumlah_kolom HARUS sama dengan jumlah kolom tabel data di bawahnya,
// supaya baris judul/alamat/garis bisa colspan penuh selebar tabel (tidak
// nyempil di sebagian kolom doang seperti sebelumnya).
function kop_surat($judul, $sub_judul, $jumlah_kolom) {
    $logo_url = logo_url_absolut();
    $sisa_kolom = max(1, $jumlah_kolom - 1); // kolom setelah kolom logo
    ob_start();
    ?>
    <table style="width:100%; border-collapse:collapse;">
        <tr>
            <td rowspan="2" style="border:none; vertical-align:middle; width:90px; padding:4px 10px 4px 0;">
                <img src="<?= htmlspecialchars($logo_url) ?>" width="75">
            </td>
            <td colspan="<?= $sisa_kolom ?>" style="border:none; text-align:center; vertical-align:bottom; padding-top:6px; white-space:nowrap;">
                <strong style="font-size:16px;"><?= htmlspecialchars(INSTANSI_NAMA) ?></strong>
            </td>
        </tr>
        <tr>
            <td colspan="<?= $sisa_kolom ?>" style="border:none; text-align:center; vertical-align:top; padding-bottom:6px;">
                <span style="font-size:11px;"><?= htmlspecialchars(INSTANSI_ALAMAT) ?></span>
            </td>
        </tr>
        <tr>
            <td colspan="<?= $jumlah_kolom ?>" style="border:none; border-bottom:2px solid #000; padding:0; line-height:2px;">&nbsp;</td>
        </tr>
        <tr><td colspan="<?= $jumlah_kolom ?>" style="border:none; height:14px; line-height:14px;">&nbsp;</td></tr>
        <tr>
            <td colspan="<?= $jumlah_kolom ?>" style="border:none; text-align:center;">
                <strong style="font-size:14px;"><?= htmlspecialchars($judul) ?></strong><br>
                <span style="font-size:12px;"><?= htmlspecialchars($sub_judul) ?></span>
            </td>
        </tr>
        <tr><td colspan="<?= $jumlah_kolom ?>" style="border:none; height:16px; line-height:16px;">&nbsp;</td></tr>
    </table>
    <?php
    return ob_get_clean();
}

// Identitas ringkas di atas tabel: cuma Nama peserta saja (periode data sudah
// ditampilkan sebagai sub judul di kop_surat).
function blok_nama_peserta($nama) {
    ob_start();
    ?>
    <table style="border-collapse:collapse; font-size:12px; margin-bottom:10px;">
        <tr><td style="border:none; padding:2px 8px 2px 0; width:60px;">Nama</td><td style="border:none; padding:2px 0;">: <?= htmlspecialchars($nama) ?></td></tr>
    </table>
    <?php
    return ob_get_clean();
}

// Blok tanda tangan: Mentor (kiri, "Mengetahui,", mentok ke batas kiri tabel) +
// Kasubag Umum (kanan, mentok ke batas kanan tabel). $jumlah_kolom dipakai supaya
// colspan-nya konsisten selebar tabel data di atasnya.
// $nama_mentor / $nip_mentor: kalau diisi (data peserta spesifik), dipakai langsung.
// Kalau kosong/null, kolom Mentor pakai garis kosong + NIP titik-titik (rekap gabungan banyak peserta).
function blok_tanda_tangan($jumlah_kolom, $nama_mentor = null, $nip_mentor = null) {
    $nip_placeholder = '.....................................';
    $garis_kosong = str_repeat('&nbsp;', 20);

    // Bagi rata full lebar tabel: separuh buat Mentor (kiri), separuh buat Kasubag Umum (kanan)
    $kolom_mentor = max(1, (int) ceil($jumlah_kolom / 2));
    $kolom_pj = $jumlah_kolom - $kolom_mentor;

    ob_start();
    ?>
    <!-- Jarak sekitar 2 baris dari tabel data di atasnya -->
    <table style="width:100%; border-collapse:collapse;">
        <tr><td style="border:none; height:20px; line-height:20px;">&nbsp;</td></tr>
        <tr><td style="border:none; height:20px; line-height:20px;">&nbsp;</td></tr>
    </table>
    <table style="width:100%; border-collapse:collapse;">
        <tr>
            <td colspan="<?= $kolom_mentor ?>" style="border:none; text-align:center;">Mengetahui,<br>Mentor</td>
            <td colspan="<?= $kolom_pj ?>" style="border:none; text-align:center;">Padang Panjang, <?= date('d F Y') ?><br><?= htmlspecialchars(PENANGGUNG_JAWAB_JABATAN) ?></td>
        </tr>
        <tr><td colspan="<?= $jumlah_kolom ?>" style="border:none; height:55px; line-height:55px;">&nbsp;</td></tr>
        <tr>
            <td colspan="<?= $kolom_mentor ?>" style="border:none; text-align:center;">
                <strong><u><?= $nama_mentor ? htmlspecialchars($nama_mentor) : $garis_kosong ?></u></strong><br>
                NIP. <?= $nip_mentor ? htmlspecialchars($nip_mentor) : $nip_placeholder ?>
            </td>
            <td colspan="<?= $kolom_pj ?>" style="border:none; text-align:center;">
                <strong><u><?= htmlspecialchars(PENANGGUNG_JAWAB_NAMA) ?></u></strong><br>
                NIP. <?= htmlspecialchars(PENANGGUNG_JAWAB_NIP) ?>
            </td>
        </tr>
    </table>
    <?php
    return ob_get_clean();
}

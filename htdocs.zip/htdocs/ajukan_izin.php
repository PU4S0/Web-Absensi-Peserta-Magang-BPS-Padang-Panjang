<?php
require_once 'includes/auth.php';
require_once 'includes/db.php';
require_peserta_login();

$peserta_id = $_SESSION['peserta_id'];
$error = "";
$success = "";

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $tanggal = $_POST['tanggal'];
    $jenis = $_POST['jenis']; // izin | sakit
    $keterangan = trim($_POST['keterangan']);

    if (!in_array($jenis, ['izin', 'sakit'])) {
        $error = "Jenis pengajuan tidak valid.";
    } elseif ($keterangan === '') {
        $error = "Keterangan wajib diisi.";
    } elseif (strtotime($tanggal) < strtotime(date('Y-m-d', strtotime('-7 days')))) {
        $error = "Pengajuan izin/sakit cuma bisa untuk maksimal 7 hari ke belakang.";
    } else {
        // Cek apakah tanggal itu sudah ada absensi hadir (sudah absen masuk)
        $stmt = $conn->prepare("SELECT status, jam_masuk FROM absensi WHERE peserta_id = ? AND tanggal = ?");
        $stmt->bind_param("is", $peserta_id, $tanggal);
        $stmt->execute();
        $existing = $stmt->get_result()->fetch_assoc();
        $stmt->close();

        if ($existing && $existing['jam_masuk']) {
            $error = "Kamu sudah tercatat hadir pada tanggal ini, tidak bisa mengajukan izin/sakit.";
        } else {
            $stmt = $conn->prepare("
                INSERT INTO pengajuan (peserta_id, tanggal, jenis, keterangan)
                VALUES (?, ?, ?, ?)
            ");
            $stmt->bind_param("isss", $peserta_id, $tanggal, $jenis, $keterangan);
            if ($stmt->execute()) {
                $success = "Pengajuan " . $jenis . " untuk tanggal " . date('d M Y', strtotime($tanggal)) . " berhasil dikirim, menunggu persetujuan admin.";
            } else {
                $error = "Gagal mengirim pengajuan, coba lagi.";
            }
            $stmt->close();
        }
    }
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Ajukan Izin / Sakit</title>
    <link rel="stylesheet" href="assets/css/style.css?v=10">
</head>
<body>
    <div class="container">
        <div class="topbar">
            <div class="topbar-left">
                <img src="assets/img/logo_bps.png?v=2" alt="Logo BPS" class="topbar-logo">
                <h2>Ajukan Izin / Sakit</h2>
            </div>
            <a href="dashboard_peserta.php" class="btn-outline">&larr; Kembali</a>
        </div>

        <div class="card">
            <?php if ($error): ?>
                <script>document.addEventListener('DOMContentLoaded', function(){ tampilkanPopup(<?= json_encode($error) ?>, 'error'); });</script>
            <?php endif; ?>
            <?php if ($success): ?>
                <script>document.addEventListener('DOMContentLoaded', function(){ tampilkanPopup(<?= json_encode($success) ?>, 'success'); });</script>
            <?php endif; ?>

            <form method="POST">
                <label>Tanggal</label>
                <input type="date" name="tanggal" required max="<?= date('Y-m-d') ?>" min="<?= date('Y-m-d', strtotime('-7 days')) ?>" value="<?= date('Y-m-d') ?>">
                <p class="muted" style="text-align:left; margin-top:4px;">Maksimal 7 hari ke belakang dari hari ini.</p>

                <label>Jenis Pengajuan</label>
                <select name="jenis" required>
                    <option value="izin">Izin</option>
                    <option value="sakit">Sakit</option>
                </select>

                <label>Keterangan</label>
                <textarea name="keterangan" rows="4" required placeholder="Contoh: Ada urusan keluarga / Demam sejak semalam"></textarea>

                <button type="submit" class="btn-primary">Kirim Pengajuan</button>
            </form>
            <p class="muted">Pengajuan akan ditinjau oleh admin sebelum tercatat resmi di rekap absensi.</p>
        </div>
    </div>
    <?php require 'includes/footer.php'; ?>
</body>
</html>

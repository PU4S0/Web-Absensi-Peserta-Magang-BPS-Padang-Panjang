<?php
require_once 'includes/auth.php';
require_once 'includes/db.php';
require_once 'includes/config.php';
require_peserta_login();

$peserta_id = $_SESSION['peserta_id'];
$today = date('Y-m-d');
$now = date('H:i:s'); // waktu server, tidak bisa dimanipulasi lewat device

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $aksi = $_POST['aksi'] ?? '';
    $lat = $_POST['lat'] ?? null;
    $lng = $_POST['lng'] ?? null;

    // Validasi lokasi WAJIB di server juga, jangan cuma percaya JS di browser
    if ($lat === null || $lng === null || !is_numeric($lat) || !is_numeric($lng)) {
        header("Location: dashboard_peserta.php?err=lokasi");
        exit;
    }

    $jarak = hitung_jarak_meter((float)$lat, (float)$lng, KANTOR_LAT, KANTOR_LNG);
    if ($jarak > RADIUS_METER) {
        header("Location: dashboard_peserta.php?err=jauh");
        exit;
    }

    if ($aksi === 'masuk') {
        $stmt = $conn->prepare("INSERT IGNORE INTO absensi (peserta_id, tanggal, jam_masuk, lat_masuk, lng_masuk, status) VALUES (?, ?, ?, ?, ?, 'hadir')");
        $stmt->bind_param("issdd", $peserta_id, $today, $now, $lat, $lng);
        $stmt->execute();
        $baru = $stmt->affected_rows > 0;
        $stmt->close();
        header("Location: dashboard_peserta.php?absen=" . ($baru ? "masuk" : "sudah_masuk") . "&jam=" . substr($now, 0, 5));
        exit;
    } elseif ($aksi === 'pulang') {
        // Tidak ada syarat "jam_pulang IS NULL" -> boleh diklik berkali-kali,
        // setiap klik menimpa jam_pulang dengan waktu klik terakhir.
        // Tetap wajib sudah absen masuk dulu (jam_masuk harus sudah terisi).
        $stmt = $conn->prepare("UPDATE absensi SET jam_pulang = ?, lat_pulang = ?, lng_pulang = ? WHERE peserta_id = ? AND tanggal = ? AND jam_masuk IS NOT NULL");
        $stmt->bind_param("sddis", $now, $lat, $lng, $peserta_id, $today);
        $stmt->execute();
        $stmt->close();

        $stmt = $conn->prepare("SELECT 1 FROM absensi WHERE peserta_id = ? AND tanggal = ? AND jam_masuk IS NOT NULL");
        $stmt->bind_param("is", $peserta_id, $today);
        $stmt->execute();
        $ada_masuk = $stmt->get_result()->num_rows > 0;
        $stmt->close();
        header("Location: dashboard_peserta.php?absen=" . ($ada_masuk ? "pulang" : "belum_masuk") . "&jam=" . substr($now, 0, 5));
        exit;
    }
}

header("Location: dashboard_peserta.php");
exit;

<?php
require_once 'includes/auth.php';
require_once 'includes/db.php';
require_once 'includes/config.php';
require_once 'includes/export_helper.php';
require_peserta_login();

$peserta_id = $_SESSION['peserta_id'];
$dari = $_GET['dari'] ?? null;
$sampai = $_GET['sampai'] ?? null;

$stmt = $conn->prepare("SELECT * FROM peserta WHERE id = ?");
$stmt->bind_param("i", $peserta_id);
$stmt->execute();
$peserta = $stmt->get_result()->fetch_assoc();
$stmt->close();

// Catatan kegiatan harian (ikut filter periode)
$sqlk = "SELECT tanggal, deskripsi FROM kegiatan_harian WHERE peserta_id = ?";
$typesk = "i";
$paramsk = [$peserta_id];
if ($dari) { $sqlk .= " AND tanggal >= ?"; $typesk .= "s"; $paramsk[] = $dari; }
if ($sampai) { $sqlk .= " AND tanggal <= ?"; $typesk .= "s"; $paramsk[] = $sampai; }
$sqlk .= " ORDER BY tanggal ASC, created_at ASC";
$stmt = $conn->prepare($sqlk);
$stmt->bind_param($typesk, ...$paramsk);
$stmt->execute();
$kegiatan = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
$stmt->close();

$sql = "SELECT * FROM absensi WHERE peserta_id = ?";
$types = "i";
$params = [$peserta_id];

if ($dari) { $sql .= " AND tanggal >= ?"; $types .= "s"; $params[] = $dari; }
if ($sampai) { $sql .= " AND tanggal <= ?"; $types .= "s"; $params[] = $sampai; }
$sql .= " ORDER BY tanggal ASC";

$stmt = $conn->prepare($sql);
$stmt->bind_param($types, ...$params);
$stmt->execute();
$data_mentah = $stmt->get_result();
$stmt->close();

// Gabungkan dengan hari kerja yang lewat tanpa absen sama sekali -> "Tidak Hadir"
$data = [];
$total = ['hadir' => 0, 'izin' => 0, 'sakit' => 0, 'tidak-hadir' => 0];
while ($r = $data_mentah->fetch_assoc()) {
    $data[] = $r;
    if (isset($total[$r['status']])) $total[$r['status']]++;
}
$dari_hitung = $dari ?: $peserta['tanggal_mulai'];
$sampai_hitung = $sampai ?: date('Y-m-d');
foreach (tanggal_tidak_hadir($conn, $peserta_id, $peserta['tanggal_mulai'], $peserta['tanggal_selesai'], $dari_hitung, $sampai_hitung) as $tgl) {
    $data[] = ['tanggal' => $tgl, 'jam_masuk' => null, 'jam_pulang' => null, 'status' => 'tidak-hadir', 'keterangan' => null];
    $total['tidak-hadir']++;
}
usort($data, function ($a, $b) { return strcmp($a['tanggal'], $b['tanggal']); });

$label_periode = "Semua Data";
if ($dari && $sampai) {
    $label_periode = "Periode: " . date('d F Y', strtotime($dari)) . " s/d " . date('d F Y', strtotime($sampai));
} elseif ($dari) {
    $label_periode = "Periode: Sejak " . date('d F Y', strtotime($dari));
} elseif ($sampai) {
    $label_periode = "Periode: Sampai " . date('d F Y', strtotime($sampai));
}

$filename = "riwayat_absensi_" . preg_replace('/[^a-zA-Z0-9]+/', '_', $peserta['nama']) . ".xls";

header("Content-Type: application/vnd.ms-excel; charset=utf-8");
header("Content-Disposition: attachment; filename=\"$filename\"");
echo "\xEF\xBB\xBF";
echo buka_dokumen_excel();
echo kop_surat('RIWAYAT ABSENSI PESERTA MAGANG', $label_periode, 6);
echo blok_nama_peserta($peserta['nama']);
?>
<table border="1" style="border-collapse:collapse; width:100%; table-layout:fixed;">
    <colgroup>
        <col style="width:40px;"><col style="width:110px;"><col style="width:90px;"><col style="width:90px;"><col style="width:70px;"><col style="width:220px;">
    </colgroup>
    <tr style="background:#f0f0f0;">
        <th>No</th><th>Tanggal</th><th>Jam Datang</th><th>Jam Pulang</th><th>Status</th><th>Keterangan</th>
    </tr>
    <?php $no = 1; foreach ($data as $row): ?>
    <tr>
        <td style="text-align:center;"><?= $no++ ?></td>
        <td><?= date('d F Y', strtotime($row['tanggal'])) ?></td>
        <td style="text-align:center;"><?= $row['jam_masuk'] ?? '-' ?></td>
        <td style="text-align:center;"><?= $row['jam_pulang'] ?? '-' ?></td>
        <td style="text-align:center;"><?= $row['status'] === 'tidak-hadir' ? 'Tidak Hadir' : ucfirst($row['status']) ?></td>
        <td><?= htmlspecialchars($row['keterangan'] ?? '-') ?></td>
    </tr>
    <?php endforeach; ?>
</table>

<table style="border-collapse:collapse; font-size:12px; margin-top:10px;">
    <tr><td style="border:none; padding:2px 8px 2px 0;"><strong>Ringkasan:</strong></td>
        <td style="border:none; padding:2px 10px;">Hadir: <?= $total['hadir'] ?> hari</td>
        <td style="border:none; padding:2px 10px;">Izin: <?= $total['izin'] ?> hari</td>
        <td style="border:none; padding:2px 10px;">Sakit: <?= $total['sakit'] ?> hari</td>
        <td style="border:none; padding:2px 10px;">Tidak Hadir: <?= $total['tidak-hadir'] ?> hari</td></tr>
</table>

<table style="border-collapse:collapse; font-size:12px; margin-top:14px;">
    <tr><td style="border:none; padding:2px 0;"><strong>Catatan Kegiatan Harian</strong></td></tr>
</table>
<table border="1" style="border-collapse:collapse; width:100%; table-layout:fixed;">
    <colgroup>
        <col style="width:40px;"><col style="width:110px;"><col style="width:90px;"><col style="width:90px;"><col style="width:70px;"><col style="width:220px;">
    </colgroup>
    <tr style="background:#f0f0f0;">
        <th>No</th><th>Tanggal</th><th colspan="4" style="text-align:left;">Kegiatan</th>
    </tr>
    <?php if ($kegiatan): $nk = 1; foreach ($kegiatan as $k): ?>
    <tr>
        <td style="text-align:center; vertical-align:top;"><?= $nk++ ?></td>
        <td style="vertical-align:top;"><?= date('d F Y', strtotime($k['tanggal'])) ?></td>
        <td colspan="4" style="vertical-align:top;"><?= nl2br(htmlspecialchars($k['deskripsi'])) ?></td>
    </tr>
    <?php endforeach; else: ?>
    <tr><td>&nbsp;</td><td>&nbsp;</td><td colspan="4">&nbsp;</td></tr>
    <?php endif; ?>
</table>

<?= blok_tanda_tangan(6, $peserta['nama_mentor'] ?: null, $peserta['nip_mentor'] ?: null) ?>
<?php echo tutup_dokumen_excel(); ?>

<?php
require_once 'includes/auth.php';
require_once 'includes/db.php';
require_once 'includes/config.php';
require_once 'includes/export_helper.php';
require_admin_login();

$tanggal_filter = $_GET['tanggal'] ?? date('Y-m-d');

$stmt = $conn->prepare("
    SELECT p.nama, a.jam_masuk, a.jam_pulang, a.status, a.keterangan, p.tanggal_mulai, p.tanggal_selesai
    FROM peserta p
    LEFT JOIN absensi a ON a.peserta_id = p.id AND a.tanggal = ?
    ORDER BY p.nama ASC
");
$stmt->bind_param("s", $tanggal_filter);
$stmt->execute();
$data = $stmt->get_result();
$stmt->close();

// Catatan kegiatan semua peserta pada tanggal tersebut
$stmt = $conn->prepare("
    SELECT p.nama, k.deskripsi
    FROM kegiatan_harian k
    JOIN peserta p ON p.id = k.peserta_id
    WHERE k.tanggal = ?
    ORDER BY p.nama ASC, k.created_at ASC
");
$stmt->bind_param("s", $tanggal_filter);
$stmt->execute();
$kegiatan = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
$stmt->close();

$filename = "rekap_absen_harian_" . $tanggal_filter . ".xls";

header("Content-Type: application/vnd.ms-excel; charset=utf-8");
header("Content-Disposition: attachment; filename=\"$filename\"");
echo "\xEF\xBB\xBF";
echo buka_dokumen_excel();
echo kop_surat('REKAP ABSENSI HARIAN PESERTA MAGANG', 'Tanggal: ' . date('d F Y', strtotime($tanggal_filter)), 6);
?>
<table border="1" style="border-collapse:collapse; width:100%; table-layout:fixed;">
    <colgroup>
        <col style="width:40px;"><col><col style="width:90px;"><col style="width:90px;"><col style="width:90px;"><col style="width:220px;">
    </colgroup>
    <tr style="background:#f0f0f0;">
        <th>No</th><th>Nama</th><th>Jam Datang</th><th>Jam Pulang</th><th>Kehadiran</th><th>Keterangan</th>
    </tr>
    <?php $no = 1; while ($row = $data->fetch_assoc()): ?>
    <tr>
        <td style="text-align:center;"><?= $no++ ?></td>
        <td><?= htmlspecialchars($row['nama']) ?></td>
        <td style="text-align:center;"><?= $row['jam_masuk'] ?? '-' ?></td>
        <td style="text-align:center;"><?= $row['jam_pulang'] ?? '-' ?></td>
        <td style="text-align:center;"><?= $row['status'] ? ucfirst($row['status']) : (tidak_hadir_hari_ini($tanggal_filter, $row['tanggal_mulai'], $row['tanggal_selesai']) ? 'Tidak Hadir' : 'Belum Absen') ?></td>
        <td><?= htmlspecialchars($row['keterangan'] ?? '-') ?></td>
    </tr>
    <?php endwhile; ?>
</table>

<table style="border-collapse:collapse; font-size:12px; margin-top:14px;">
    <tr><td style="border:none; padding:2px 0;"><strong>Catatan Kegiatan Harian</strong></td></tr>
</table>
<table border="1" style="border-collapse:collapse; width:100%; table-layout:fixed;">
    <colgroup>
        <col style="width:40px;"><col><col style="width:90px;"><col style="width:90px;"><col style="width:90px;"><col style="width:220px;">
    </colgroup>
    <tr style="background:#f0f0f0;">
        <th>No</th><th>Nama</th><th colspan="4" style="text-align:left;">Kegiatan</th>
    </tr>
    <?php if ($kegiatan): $nk = 1; foreach ($kegiatan as $k): ?>
    <tr>
        <td style="text-align:center; vertical-align:top;"><?= $nk++ ?></td>
        <td style="vertical-align:top;"><?= htmlspecialchars($k['nama']) ?></td>
        <td colspan="4" style="vertical-align:top;"><?= nl2br(htmlspecialchars($k['deskripsi'])) ?></td>
    </tr>
    <?php endforeach; else: ?>
    <tr><td>&nbsp;</td><td>&nbsp;</td><td colspan="4">&nbsp;</td></tr>
    <?php endif; ?>
</table>

<?= blok_tanda_tangan(6) ?>
<?php echo tutup_dokumen_excel(); ?>

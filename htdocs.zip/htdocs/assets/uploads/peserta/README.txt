Folder ini menyimpan foto profil peserta. Jangan dihapus.

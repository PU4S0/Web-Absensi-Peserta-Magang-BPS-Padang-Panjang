<?php
require_once 'includes/auth.php';
require_once 'includes/db.php';
require_once 'includes/config.php';
require_admin_login();

$bulan_filter = $_GET['bulan'] ?? date('Y-m');

$stmt = $conn->prepare("
    SELECT p.id, p.nama, p.tanggal_mulai, p.tanggal_selesai,
           SUM(CASE WHEN a.status = 'hadir' THEN 1 ELSE 0 END) AS jumlah_hadir,
           SUM(CASE WHEN a.status = 'izin' THEN 1 ELSE 0 END) AS jumlah_izin,
           SUM(CASE WHEN a.status = 'sakit' THEN 1 ELSE 0 END) AS jumlah_sakit,
           SUM(CASE WHEN a.jam_masuk IS NOT NULL AND a.jam_pulang IS NOT NULL THEN 1 ELSE 0 END) AS lengkap
    FROM peserta p
    LEFT JOIN absensi a ON a.peserta_id = p.id AND DATE_FORMAT(a.tanggal, '%Y-%m') = ?
    GROUP BY p.id
    ORDER BY p.nama ASC
");
$stmt->bind_param("s", $bulan_filter);
$stmt->execute();
$rekap_mentah = $stmt->get_result();
$stmt->close();

// Tambahkan hitungan "Tidak Hadir" per peserta (hari kerja lewat tanpa record absensi apapun)
$awal_bulan = $bulan_filter . '-01';
$akhir_bulan = date('Y-m-t', strtotime($awal_bulan));
$rekap = [];
while ($r = $rekap_mentah->fetch_assoc()) {
    $r['tidak_hadir'] = count(tanggal_tidak_hadir($conn, $r['id'], $r['tanggal_mulai'], $r['tanggal_selesai'], $awal_bulan, $akhir_bulan));
    $rekap[] = $r;
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Rekap Bulanan</title>
    <link rel="stylesheet" href="https://cdn.datatables.net/2.1.8/css/dataTables.dataTables.min.css">
    <link rel="stylesheet" href="assets/css/style.css?v=10">
</head>
<body>
    <div class="container container-wide">
        <div class="topbar">
            <div class="topbar-left">
                <img src="assets/img/logo_bps.png?v=2" alt="Logo BPS" class="topbar-logo">
                <h2>Rekap Absensi Bulanan</h2>
            </div>
            <a href="admin_dashboard.php" class="btn-outline">&larr; Kembali</a>
        </div>

        <div class="card">
            <form method="GET" class="filter-row">
                <label>Bulan:</label>
                <input type="month" name="bulan" value="<?= htmlspecialchars($bulan_filter) ?>">
                <button type="submit" class="btn-primary">Tampilkan</button>
                <a href="export_bulanan.php?bulan=<?= htmlspecialchars($bulan_filter) ?>" class="btn-outline">Download Excel</a>
            </form>

            <div class="dt-filter-bar">
                <div class="dt-filter-item">
                    <label>Cari Nama</label>
                    <input type="text" id="filter-nama" placeholder="Ketik nama...">
                </div>
                <div class="dt-filter-item">
                    <label>Status Magang</label>
                    <select id="filter-status">
                        <option value="">Semua</option>
                        <option value="Aktif">Aktif</option>
                        <option value="Tidak Aktif">Tidak Aktif</option>
                    </select>
                </div>
            </div>

            <table id="tabel-bulanan" class="display">
                <thead>
                <tr>
                    <th>Nama</th><th>Hadir</th><th>Izin</th><th>Sakit</th><th>Tidak Hadir</th><th>Absen Lengkap (Masuk &amp; Pulang)</th><th>Status Magang</th>
                </tr>
                </thead>
                <tbody>
                <?php foreach ($rekap as $row): $st = status_peserta($row['tanggal_selesai']); ?>
                <tr>
                    <td><?= htmlspecialchars($row['nama']) ?></td>
                    <td><?= (int)$row['jumlah_hadir'] ?></td>
                    <td><?= (int)$row['jumlah_izin'] ?></td>
                    <td><?= (int)$row['jumlah_sakit'] ?></td>
                    <td><?= (int)$row['tidak_hadir'] ?></td>
                    <td><?= (int)$row['lengkap'] ?></td>
                    <td><span class="badge <?= $st === 'Aktif' ? 'badge-aktif' : 'badge-tidak-aktif' ?>"><?= $st ?></span></td>
                </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
    <script src="https://cdn.datatables.net/2.1.8/js/dataTables.min.js"></script>
    <script>
        $(document).ready(function () {
            const tabel = $('#tabel-bulanan').DataTable({ order: [[0, 'asc']], pageLength: 15 });

            $('#filter-nama').on('keyup', function () {
                tabel.column(0).search(this.value).draw();
            });
            $('#filter-status').on('change', function () {
                const val = this.value;
                tabel.column(6).search(val ? '^' + val + '$' : '', true, false).draw();
            });
        });
    </script>
    <?php require 'includes/footer.php'; ?>
</body>
</html>

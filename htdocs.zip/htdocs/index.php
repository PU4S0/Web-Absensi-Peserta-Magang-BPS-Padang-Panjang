<?php ini_set('display_errors', 1); error_reporting(E_ALL); ?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Absensi Magang - BPS Kota Padang Panjang</title>
    <link rel="stylesheet" href="assets/css/style.css?v=10">
</head>
<body>
    <div class="landing">
        <img src="assets/img/logo_bps.png?v=2" alt="Logo BPS" class="landing-logo">
        <h1>Selamat Datang</h1>
        <p class="landing-sub">Sistem Absensi Peserta Magang<br>Badan Pusat Statistik Kota Padang Panjang</p>

        <div class="landing-actions">
            <a href="login.php" class="btn-primary btn-block">Login Peserta Magang</a>
            <a href="signup.php" class="btn-outline btn-block">Daftar Peserta Magang Baru</a>
            <a href="admin_login.php" class="btn-link">Login sebagai Admin</a>
        </div>
    </div>

    <?php require 'includes/footer.php'; ?>
</body>
</html>

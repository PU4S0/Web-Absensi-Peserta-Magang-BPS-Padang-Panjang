<?php
require_once 'includes/auth.php';
require_once 'includes/db.php';
require_once 'includes/upload_helper.php';
require_admin_login();

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['id'])) {
    $id = (int)$_POST['id'];

    // Hapus file foto profil dulu sebelum record-nya hilang
    $stmt = $conn->prepare("SELECT foto FROM peserta WHERE id = ?");
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $p = $stmt->get_result()->fetch_assoc();
    $stmt->close();
    if ($p) hapus_foto_profil($p['foto']);

    // Riwayat absensi ikut terhapus otomatis lewat ON DELETE CASCADE di database
    $stmt = $conn->prepare("DELETE FROM peserta WHERE id = ?");
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $stmt->close();
}

header("Location: peserta_admin.php?msg=" . urlencode("Peserta berhasil dihapus."));
exit;

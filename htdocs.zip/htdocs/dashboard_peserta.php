<?php
require_once 'includes/auth.php';
require_once 'includes/db.php';
require_once 'includes/config.php';
require_once 'includes/upload_helper.php';
require_peserta_login();

$peserta_id = $_SESSION['peserta_id'];
$today = date('Y-m-d');

// Ambil data peserta (untuk cek status aktif/tidak)
$stmt = $conn->prepare("SELECT * FROM peserta WHERE id = ?");
$stmt->bind_param("i", $peserta_id);
$stmt->execute();
$peserta = $stmt->get_result()->fetch_assoc();
$stmt->close();

$status_magang = status_peserta($peserta['tanggal_selesai']);

// Cek status absen hari ini
$stmt = $conn->prepare("SELECT * FROM absensi WHERE peserta_id = ? AND tanggal = ?");
$stmt->bind_param("is", $peserta_id, $today);
$stmt->execute();
$absen_hari_ini = $stmt->get_result()->fetch_assoc();
$stmt->close();

// Seluruh riwayat absensi (untuk DataTable, tidak dibatasi lagi karena sudah ada paging bawaan DataTables)
$stmt = $conn->prepare("SELECT * FROM absensi WHERE peserta_id = ? ORDER BY tanggal DESC");
$stmt->bind_param("i", $peserta_id);
$stmt->execute();
$riwayat = $stmt->get_result();

// Gabungkan riwayat asli dengan hari kerja yang lewat tanpa absen sama sekali -> "Tidak Hadir"
$riwayat_gabung = [];
while ($r = $riwayat->fetch_assoc()) {
    $riwayat_gabung[] = $r;
}
foreach (tanggal_tidak_hadir($conn, $peserta_id, $peserta['tanggal_mulai'], $peserta['tanggal_selesai'], $peserta['tanggal_mulai'], date('Y-m-d')) as $tgl) {
    $riwayat_gabung[] = ['tanggal' => $tgl, 'jam_masuk' => null, 'jam_pulang' => null, 'status' => 'tidak-hadir'];
}
usort($riwayat_gabung, function ($a, $b) { return strcmp($b['tanggal'], $a['tanggal']); });
$stmt->close();

// Riwayat pengajuan (absen manual / izin / sakit) milik peserta ini
$stmt = $conn->prepare("SELECT * FROM pengajuan WHERE peserta_id = ? ORDER BY created_at DESC");
$stmt->bind_param("i", $peserta_id);
$stmt->execute();
$pengajuan_list = $stmt->get_result();
$stmt->close();

// Catatan kegiatan harian milik peserta ini
$stmt = $conn->prepare("SELECT * FROM kegiatan_harian WHERE peserta_id = ? ORDER BY tanggal DESC, created_at DESC");
$stmt->bind_param("i", $peserta_id);
$stmt->execute();
$kegiatan_list = $stmt->get_result();
$stmt->close();

function label_jenis_pengajuan($jenis) {
    return ['absen_manual' => 'Absen Manual', 'izin' => 'Izin', 'sakit' => 'Sakit'][$jenis] ?? $jenis;
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Dashboard Peserta</title>
    <link rel="stylesheet" href="https://cdn.datatables.net/2.1.8/css/dataTables.dataTables.min.css">
    <link rel="stylesheet" href="assets/css/style.css?v=10">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/maplibre-gl@3.6.2/dist/maplibre-gl.css">
    <style>
        .peta-wrapper { height: 280px; width: 100%; border-radius: 10px; overflow: hidden; margin: 14px 0; }
        #peta-lokasi { height: 100%; width: 100%; }
    </style>
</head>
<body class="body-hero">
    <div class="hero-header">
        <div class="hero-topbar">
            <div class="hero-profile">
                <?php $foto_url_hero = url_foto_profil($peserta['foto']); ?>
                <?php if ($foto_url_hero): ?>
                    <img src="<?= htmlspecialchars($foto_url_hero) ?>" alt="Foto profil" class="avatar-circle" style="object-fit:cover;">
                <?php else: ?>
                    <div class="avatar-circle"><?= strtoupper(substr($_SESSION['peserta_nama'], 0, 1)) ?></div>
                <?php endif; ?>
                <div>
                    <p class="hero-name"><?= htmlspecialchars($_SESSION['peserta_nama']) ?></p>
                    <p class="hero-sub"><?= htmlspecialchars($peserta['asal_universitas']) ?></p>
                </div>
            </div>
            <div class="hero-icon-actions">
                <a href="kelola_profil.php" class="icon-btn" title="Kelola Profil">
                    <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="3"></circle><path d="M19.4 15a1.65 1.65 0 00.33 1.82l.06.06a2 2 0 11-2.83 2.83l-.06-.06a1.65 1.65 0 00-1.82-.33 1.65 1.65 0 00-1 1.51V21a2 2 0 11-4 0v-.09a1.65 1.65 0 00-1-1.51 1.65 1.65 0 00-1.82.33l-.06.06a2 2 0 11-2.83-2.83l.06-.06a1.65 1.65 0 00.33-1.82 1.65 1.65 0 00-1.51-1H3a2 2 0 110-4h.09a1.65 1.65 0 001.51-1 1.65 1.65 0 00-.33-1.82l-.06-.06a2 2 0 112.83-2.83l.06.06a1.65 1.65 0 001.82.33H9a1.65 1.65 0 001-1.51V3a2 2 0 114 0v.09a1.65 1.65 0 001 1.51 1.65 1.65 0 001.82-.33l.06-.06a2 2 0 112.83 2.83l-.06.06a1.65 1.65 0 00-.33 1.82V9a1.65 1.65 0 001.51 1H21a2 2 0 110 4h-.09a1.65 1.65 0 00-1.51 1z"></path></svg>
                </a>
                <a href="logout.php" class="icon-btn" title="Logout">
                    <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M9 21H5a2 2 0 01-2-2V5a2 2 0 012-2h4"></path><polyline points="16 17 21 12 16 7"></polyline><line x1="21" y1="12" x2="9" y2="12"></line></svg>
                </a>
            </div>
        </div>

        <div class="hero-date-row">
            <span class="hero-date-pill"><?= strftime_id(date('N')) ?>, <?= tanggal_indonesia(time()) ?></span>
            <span class="hero-status-badge <?= $status_magang === 'Aktif' ? 'badge-wfo-aktif' : 'badge-wfo-tidak' ?>"><?= strtoupper($status_magang) ?></span>
        </div>
    </div>

    <?php if (isset($_GET['err'])): ?>
        <script>document.addEventListener('DOMContentLoaded', function(){
            tampilkanPopup(<?= json_encode($_GET['err'] === 'jauh' ? 'Absen ditolak: lokasi kamu di luar radius kantor.' : 'Absen ditolak: data lokasi tidak valid, coba lagi.') ?>, 'error');
        });</script>
    <?php endif; ?>

    <?php if (isset($_GET['absen'])):
        $jam_notif = preg_match('/^\d{2}:\d{2}$/', $_GET['jam'] ?? '') ? $_GET['jam'] : '';
        $pesan_absen = [
            'masuk' => ['Absen masuk berhasil dicatat pukul ' . $jam_notif . '.', 'success'],
            'sudah_masuk' => ['Kamu sudah absen masuk hari ini.', 'error'],
            'pulang' => ['Absen pulang berhasil dicatat pukul ' . $jam_notif . '.', 'success'],
            'belum_masuk' => ['Kamu belum absen masuk hari ini, absen pulang belum bisa dicatat.', 'error'],
        ][$_GET['absen']] ?? null;
        if ($pesan_absen): ?>
        <script>document.addEventListener('DOMContentLoaded', function(){
            tampilkanPopup(<?= json_encode($pesan_absen[0]) ?>, <?= json_encode($pesan_absen[1]) ?>);
            if (history.replaceState) history.replaceState(null, '', 'dashboard_peserta.php');
        });</script>
    <?php endif; endif; ?>

    <!-- ===== Kartu jam datang / jam pulang, nempel di bawah header ===== -->
    <div class="stat-card-overlap">
        <div class="stat-col">
            <p class="stat-time-label">Jam Datang</p>
            <p class="stat-time-value"><?= $absen_hari_ini && $absen_hari_ini['jam_masuk'] ? substr($absen_hari_ini['jam_masuk'], 0, 5) : '--:--' ?></p>
        </div>
        <div class="stat-divider"></div>
        <div class="stat-col">
            <p class="stat-time-label">Jam Pulang</p>
            <p class="stat-time-value"><?= $absen_hari_ini && $absen_hari_ini['jam_pulang'] ? substr($absen_hari_ini['jam_pulang'], 0, 5) : '--:--' ?></p>
        </div>
    </div>

    <!-- ===== Grid tombol aksi cepat ===== -->
    <div class="quick-actions-grid">
        <a href="#bagian-riwayat" class="quick-action-btn">
            <span class="quick-action-icon">
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="4" width="18" height="18" rx="2"></rect><line x1="16" y1="2" x2="16" y2="6"></line><line x1="8" y1="2" x2="8" y2="6"></line><line x1="3" y1="10" x2="21" y2="10"></line></svg>
            </span>
            <span class="quick-action-label">Presensi<br>Bulanan</span>
        </a>
        <a href="#bagian-absen" class="quick-action-btn">
            <span class="quick-action-icon">
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0118 0z"></path><circle cx="12" cy="10" r="3"></circle></svg>
            </span>
            <span class="quick-action-label">Buat<br>Kehadiran</span>
        </a>
        <a href="ajukan_absen_manual.php" class="quick-action-btn">
            <span class="quick-action-icon">
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M11 4H4a2 2 0 00-2 2v14a2 2 0 002 2h14a2 2 0 002-2v-7"></path><path d="M18.5 2.5a2.121 2.121 0 013 3L12 15l-4 1 1-4 9.5-9.5z"></path></svg>
            </span>
            <span class="quick-action-label">Presensi<br>Manual</span>
        </a>
        <a href="ajukan_izin.php" class="quick-action-btn">
            <span class="quick-action-icon">
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M19 14c1.49-1.46 3-3.21 3-5.5A5.5 5.5 0 0016.5 3c-1.76 0-3 .5-4.5 2-1.5-1.5-2.74-2-4.5-2A5.5 5.5 0 002 8.5c0 2.29 1.51 4.04 3 5.5l7 7z"></path></svg>
            </span>
            <span class="quick-action-label">Izin /<br>Sakit</span>
        </a>
    </div>

    <div class="container container-wide">
        <div class="card" id="bagian-absen">
            <h3>Absensi Hari Ini (<?= date('d M Y') ?>)</h3>

            <?php if ($status_magang !== 'Aktif'): ?>
                <p class="alert">Masa magang kamu sudah berakhir, absensi tidak dapat dilakukan lagi.</p>
            <?php elseif (!$absen_hari_ini): ?>
                <div class="peta-wrapper"><div id="peta-lokasi"></div></div>
                <p class="muted" id="lokasi-status">Menunggu izin akses lokasi untuk mengambil absen&hellip;</p>
                <button id="btn-absen-masuk" class="btn-primary" data-aksi="masuk" disabled>Ambil Absen Masuk</button>
            <?php else: ?>
                <?php if ($absen_hari_ini['jam_pulang']): ?>
                    <p class="muted">Jam pulang tercatat terakhir seperti di atas. Klik tombol di bawah lagi kalau perlu diperbarui.</p>
                <?php endif; ?>
                <div class="peta-wrapper"><div id="peta-lokasi"></div></div>
                <p class="muted" id="lokasi-status">Menunggu izin akses lokasi untuk mengambil absen&hellip;</p>
                <button id="btn-absen-pulang" class="btn-primary" data-aksi="pulang" disabled>
                    <?= $absen_hari_ini['jam_pulang'] ? 'Update Absen Pulang' : 'Ambil Absen Pulang' ?>
                </button>
                <p class="muted">Tombol ini bisa diklik ulang kapan saja sebelum benar-benar pulang &mdash; jam pulang akan selalu diperbarui ke waktu klik terakhir.</p>
            <?php endif; ?>
        </div>

        <div class="card" id="bagian-riwayat">
            <div class="card-header-row">
                <h3>Riwayat Absensi</h3>
            </div>

            <div class="dt-filter-bar">
                <div class="dt-filter-item">
                    <label>Dari Tanggal</label>
                    <input type="date" id="filter-riwayat-dari">
                </div>
                <div class="dt-filter-item">
                    <label>Sampai Tanggal</label>
                    <input type="date" id="filter-riwayat-sampai">
                </div>
                <div class="dt-filter-item">
                    <label>&nbsp;</label>
                    <a href="#" id="btn-download-riwayat" class="btn-outline">&#11015; Download Excel</a>
                </div>
            </div>
            <p class="muted" style="text-align:left; margin-top:-6px;">Download akan mengikuti rentang tanggal yang kamu atur di atas. Kosongkan kedua tanggal untuk download semua riwayat.</p>

            <table id="tabel-riwayat" class="display">
                <thead>
                <tr>
                    <th>Tanggal</th><th>Masuk</th><th>Pulang</th><th>Status</th><th>TanggalISO</th>
                </tr>
                </thead>
                <tbody>
                <?php foreach ($riwayat_gabung as $row): ?>
                <tr>
                    <td><?= date('d M Y', strtotime($row['tanggal'])) ?></td>
                    <td><?= $row['jam_masuk'] ?? '-' ?></td>
                    <td><?= $row['jam_pulang'] ?? '-' ?></td>
                    <td><span class="status-pill status-<?= $row['status'] ?>"><?= $row['status'] === 'tidak-hadir' ? 'Tidak Hadir' : ucfirst($row['status']) ?></span></td>
                    <td><?= $row['tanggal'] ?></td>
                </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
        </div>

        <div class="card">
            <h3>Status Pengajuan Saya</h3>
            <table id="tabel-pengajuan" class="display">
                <thead>
                <tr>
                    <th>Tanggal</th><th>Jenis</th><th>Keterangan</th><th>Status</th><th>Catatan Admin</th>
                </tr>
                </thead>
                <tbody>
                <?php while ($row = $pengajuan_list->fetch_assoc()): ?>
                <tr>
                    <td><?= date('d M Y', strtotime($row['tanggal'])) ?></td>
                    <td><?= label_jenis_pengajuan($row['jenis']) ?></td>
                    <td><?= htmlspecialchars($row['keterangan']) ?></td>
                    <td><span class="status-pill status-pengajuan-<?= $row['status_pengajuan'] ?>"><?= ucfirst($row['status_pengajuan']) ?></span></td>
                    <td><?= htmlspecialchars($row['catatan_admin'] ?? '-') ?></td>
                </tr>
                <?php endwhile; ?>
                </tbody>
            </table>
        </div>

        <div class="card" id="bagian-kegiatan">
            <h3>Catatan Kegiatan</h3>
            <form method="POST" action="kegiatan_simpan.php">
                <input type="hidden" name="aksi" value="tambah">
                <label>Tambah Kegiatan Hari Ini (<?= date('d M Y') ?>)</label>
                <textarea name="deskripsi" rows="3" required placeholder="Contoh: Input data survei sakernas, rekap dokumen bulanan..."></textarea>
                <button type="submit" class="btn-primary">+ Tambah Kegiatan</button>
            </form>

            <h4 style="margin:22px 0 8px;">Riwayat Kegiatan</h4>
            <table id="tabel-kegiatan" class="display">
                <thead>
                <tr>
                    <th>Tanggal</th><th>Kegiatan</th><th>Aksi</th>
                </tr>
                </thead>
                <tbody>
                <?php while ($k = $kegiatan_list->fetch_assoc()): ?>
                <tr>
                    <td><?= date('d M Y', strtotime($k['tanggal'])) ?></td>
                    <td><?= nl2br(htmlspecialchars($k['deskripsi'])) ?></td>
                    <td>
                        <?php if ($k['tanggal'] === date('Y-m-d')): ?>
                            <div class="aksi-cell">
                                <button type="button" class="btn-outline btn-sm btn-edit-kegiatan" style="cursor:pointer;"
                                        data-id="<?= $k['id'] ?>" data-deskripsi="<?= htmlspecialchars($k['deskripsi'], ENT_QUOTES) ?>">Edit</button>
                                <form method="POST" action="kegiatan_simpan.php" class="inline-form" onsubmit="return confirm('Hapus catatan kegiatan ini?');">
                                    <input type="hidden" name="aksi" value="hapus">
                                    <input type="hidden" name="id" value="<?= $k['id'] ?>">
                                    <button type="submit" class="btn-danger btn-sm">Hapus</button>
                                </form>
                            </div>
                        <?php else: ?>
                            <span class="muted-inline">-</span>
                        <?php endif; ?>
                    </td>
                </tr>
                <?php endwhile; ?>
                </tbody>
            </table>
        </div>
    </div>

    <?php if (isset($_GET['kegiatan'])): ?>
        <script>document.addEventListener('DOMContentLoaded', function(){
            <?php if ($_GET['kegiatan'] === 'ok'): ?>tampilkanPopup('Kegiatan hari ini berhasil dicatat.', 'success');
            <?php elseif ($_GET['kegiatan'] === 'hapus'): ?>tampilkanPopup('Catatan kegiatan dihapus.', 'success');
            <?php elseif ($_GET['kegiatan'] === 'edit'): ?>tampilkanPopup('Catatan kegiatan berhasil diperbarui.', 'success');
            <?php else: ?>tampilkanPopup('Deskripsi kegiatan tidak boleh kosong.', 'error');<?php endif; ?>
            if (history.replaceState) history.replaceState(null, '', 'dashboard_peserta.php#bagian-kegiatan');
        });</script>
    <?php endif; ?>

    <div id="modal-edit-kegiatan" class="modal-overlay" style="display:none;">
        <div class="modal-box">
            <h3>Edit Kegiatan</h3>
            <form method="POST" action="kegiatan_simpan.php">
                <input type="hidden" name="aksi" value="edit">
                <input type="hidden" name="id" id="edit-kegiatan-id">
                <textarea name="deskripsi" id="edit-kegiatan-deskripsi" rows="5" required></textarea>
                <div class="modal-actions">
                    <button type="button" class="btn-outline" style="cursor:pointer;" onclick="document.getElementById('modal-edit-kegiatan').style.display='none';">Batal</button>
                    <button type="submit" class="btn-primary btn-inline" style="margin-top:0; padding:8px 18px;">Simpan</button>
                </div>
            </form>
        </div>
    </div>
    <script>
        document.addEventListener('click', function (e) {
            const btn = e.target.closest('.btn-edit-kegiatan');
            if (!btn) return;
            document.getElementById('edit-kegiatan-id').value = btn.dataset.id;
            document.getElementById('edit-kegiatan-deskripsi').value = btn.dataset.deskripsi;
            document.getElementById('modal-edit-kegiatan').style.display = 'flex';
        });
    </script>

    <form id="form-absen" method="POST" action="absen.php" style="display:none;">
        <input type="hidden" name="aksi" id="input-aksi">
        <input type="hidden" name="lat" id="input-lat">
        <input type="hidden" name="lng" id="input-lng">
    </form>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
    <script src="https://cdn.datatables.net/2.1.8/js/dataTables.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/maplibre-gl@3.6.2/dist/maplibre-gl.js"></script>
    <script>
        $(document).ready(function () {
            const tabelRiwayat = $('#tabel-riwayat').DataTable({
                order: [[0, 'desc']],
                pageLength: 10,
                columnDefs: [{ targets: 4, visible: false }]
            });
            $.fn.dataTable.ext.search.push(function (settings, data) {
                if (settings.nTable.id !== 'tabel-riwayat') return true;
                const dari = $('#filter-riwayat-dari').val();
                const sampai = $('#filter-riwayat-sampai').val();
                const tgl = data[4];
                if (dari && tgl < dari) return false;
                if (sampai && tgl > sampai) return false;
                return true;
            });
            $('#filter-riwayat-dari, #filter-riwayat-sampai').on('change', function () {
                tabelRiwayat.draw();
            });

            $('#btn-download-riwayat').on('click', function (e) {
                e.preventDefault();
                const dari = $('#filter-riwayat-dari').val();
                const sampai = $('#filter-riwayat-sampai').val();
                let url = 'export_peserta.php?';
                if (dari) url += 'dari=' + encodeURIComponent(dari) + '&';
                if (sampai) url += 'sampai=' + encodeURIComponent(sampai);
                window.location.href = url;
            });

            $('#tabel-pengajuan').DataTable({ order: [[0, 'desc']], pageLength: 10 });
            $('#tabel-kegiatan').DataTable({ order: [[0, 'desc']], pageLength: 10 });
        });

        // ===== Lock lokasi + peta =====
        const RADIUS_MAKS = <?= RADIUS_METER ?>;
        const KANTOR_LAT = <?= KANTOR_LAT ?>;
        const KANTOR_LNG = <?= KANTOR_LNG ?>;

        function hitungJarakMeter(lat1, lng1, lat2, lng2) {
            const R = 6371000;
            const dLat = (lat2 - lat1) * Math.PI / 180;
            const dLng = (lng2 - lng1) * Math.PI / 180;
            const a = Math.sin(dLat / 2) ** 2 +
                      Math.cos(lat1 * Math.PI / 180) * Math.cos(lat2 * Math.PI / 180) *
                      Math.sin(dLng / 2) ** 2;
            const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
            return R * c;
        }

        const statusEl = document.getElementById('lokasi-status');
        const btnMasuk = document.getElementById('btn-absen-masuk');
        const btnPulang = document.getElementById('btn-absen-pulang');
        const btn = btnMasuk || btnPulang;
        const petaEl = document.getElementById('peta-lokasi');

        let posisiSaatIni = null;
        let peta, markerSaya;

        function inisialisasiPeta() {
            if (!petaEl || peta) return;

            // Style raster sederhana pakai tile OpenStreetMap gratis, tanpa perlu API key
            peta = new maplibregl.Map({
                container: 'peta-lokasi',
                style: {
                    version: 8,
                    sources: {
                        'osm': {
                            type: 'raster',
    						tiles: ['https://mt1.google.com/vt/lyrs=s&x={x}&y={y}&z={z}'],
   		 					tileSize: 256,
    						maxzoom: 20,
    						attribution: 'Imagery &copy; Google'
                        }
                    },
                    layers: [{ id: 'osm-layer', type: 'raster', source: 'osm' }]
                },
                center: [KANTOR_LNG, KANTOR_LAT], // MapLibre pakai urutan [lng, lat]
                zoom: 18
            });

            peta.on('load', () => {
                // Marker kantor
                new maplibregl.Marker({ color: '#2563eb' })
                    .setLngLat([KANTOR_LNG, KANTOR_LAT])
                    .setPopup(new maplibregl.Popup().setText('Kantor BPS Kota Padang Panjang'))
                    .addTo(peta);

                // Lingkaran radius (dibuat manual sebagai poligon geografis, karena
                // radius di MapLibre defaultnya dalam satuan piksel, bukan meter)
                peta.addSource('radius-circle', {
                    type: 'geojson',
                    data: { type: 'Feature', geometry: { type: 'Polygon', coordinates: [buatPoligonLingkaran(KANTOR_LAT, KANTOR_LNG, RADIUS_MAKS)] } }
                });
                peta.addLayer({
                    id: 'radius-fill', type: 'fill', source: 'radius-circle',
                    paint: { 'fill-color': '#2563eb', 'fill-opacity': 0.12 }
                });
                peta.addLayer({
                    id: 'radius-outline', type: 'line', source: 'radius-circle',
                    paint: { 'line-color': '#2563eb', 'line-width': 1.5 }
                });
            });

            // ResizeObserver: setiap kali ukuran kotak peta berubah, paksa MapLibre
            // hitung ulang ukuran canvas-nya. Jauh lebih andal dibanding nebak delay.
            if (window.ResizeObserver) {
                const ro = new ResizeObserver(() => peta.resize());
                ro.observe(petaEl);
            }
            window.addEventListener('resize', () => peta.resize());
            window.addEventListener('load', () => peta.resize());
        }

        // Hasilkan titik-titik poligon lingkaran geografis (dalam meter) di sekitar
        // sebuah titik pusat, dipakai untuk gambar radius kantor di peta
        function buatPoligonLingkaran(lat, lng, radiusMeter, jumlahTitik = 64) {
            const koordinat = [];
            const R = 6371000;
            const lat1 = lat * Math.PI / 180;
            const lng1 = lng * Math.PI / 180;
            for (let i = 0; i <= jumlahTitik; i++) {
                const bearing = (i * 360 / jumlahTitik) * Math.PI / 180;
                const lat2 = Math.asin(Math.sin(lat1) * Math.cos(radiusMeter / R) + Math.cos(lat1) * Math.sin(radiusMeter / R) * Math.cos(bearing));
                const lng2 = lng1 + Math.atan2(Math.sin(bearing) * Math.sin(radiusMeter / R) * Math.cos(lat1), Math.cos(radiusMeter / R) - Math.sin(lat1) * Math.sin(lat2));
                koordinat.push([lng2 * 180 / Math.PI, lat2 * 180 / Math.PI]);
            }
            return koordinat;
        }

        function updatePosisiSaya(lat, lng) {
            if (!peta) return;
            if (!markerSaya) {
                const elSaya = document.createElement('div');
                elSaya.style.cssText = 'width:16px;height:16px;border-radius:50%;background:#dc2626;border:3px solid #fff;box-shadow:0 0 4px rgba(0,0,0,0.4);';
                markerSaya = new maplibregl.Marker({ element: elSaya })
                    .setLngLat([lng, lat])
                    .setPopup(new maplibregl.Popup().setText('Posisi kamu'))
                    .addTo(peta);
            } else {
                markerSaya.setLngLat([lng, lat]);
            }
            // Zoom supaya kantor dan posisi peserta sama-sama kelihatan
            const bounds = [[Math.min(KANTOR_LNG, lng), Math.min(KANTOR_LAT, lat)], [Math.max(KANTOR_LNG, lng), Math.max(KANTOR_LAT, lat)]];
            peta.fitBounds(bounds, { padding: 50, maxZoom: 19, duration: 500 });
        }

        if (btn) {
            inisialisasiPeta();

            if (!navigator.geolocation) {
                statusEl.textContent = 'Browser kamu tidak mendukung akses lokasi. Absen tidak bisa dilakukan.';
            } else {
                navigator.geolocation.watchPosition(
                    (pos) => {
                        const akurasi = Math.round(pos.coords.accuracy); // radius kepercayaan GPS, dalam meter
                        updatePosisiSaya(pos.coords.latitude, pos.coords.longitude); // titik merah di peta selalu ikut posisi live

                        // Pakai bacaan GPS yang PALING AKURAT yang pernah didapat selama halaman terbuka,
                        // bukan cuma bacaan paling baru -- GPS HP sering ngaco di beberapa detik pertama
                        // lalu makin presisi seiring waktu. Ini mencegah ditolak gara-gara bacaan awal yang jelek.
                        if (!posisiSaatIni || akurasi <= posisiSaatIni.accuracy) {
                            posisiSaatIni = pos.coords;
                        }

                        const jarak = hitungJarakMeter(posisiSaatIni.latitude, posisiSaatIni.longitude, KANTOR_LAT, KANTOR_LNG);
                        const infoAkurasi = ' (akurasi GPS saat ini: \u00b1' + akurasi + ' m)';

                        if (jarak <= RADIUS_MAKS) {
                            statusEl.textContent = 'Lokasi terverifikasi (' + Math.round(jarak) + ' m dari kantor). Kamu bisa absen.' + infoAkurasi;
                            statusEl.className = 'muted lokasi-ok';
                            btn.disabled = false;
                        } else {
                            let pesan = 'Kamu berada ' + Math.round(jarak) + ' m dari kantor. Harus dalam radius ' + RADIUS_MAKS + ' m untuk bisa absen.' + infoAkurasi;
                            if (akurasi > RADIUS_MAKS) {
                                pesan += ' Akurasi GPS kamu masih kasar, coba pindah ke area terbuka (bukan dalam ruangan) atau tunggu beberapa detik lagi.';
                            }
                            statusEl.textContent = pesan;
                            statusEl.className = 'muted lokasi-jauh';
                            btn.disabled = true;
                        }
                    },
                    (err) => {
                        if (location.protocol !== 'https:' && location.hostname !== 'localhost' && location.hostname !== '127.0.0.1') {
                            statusEl.textContent = 'Akses lokasi diblokir browser karena halaman ini dibuka lewat HTTP biasa (bukan HTTPS). Buka lewat "localhost" di komputer, atau pakai HTTPS (misal lewat ngrok) kalau mau akses dari HP.';
                        } else {
                            statusEl.textContent = 'Gagal mengambil lokasi: ' + err.message + '. Aktifkan izin lokasi lalu muat ulang halaman.';
                        }
                        btn.disabled = true;
                    },
                    { enableHighAccuracy: true, maximumAge: 0, timeout: 15000 }
                );
            }

            btn.addEventListener('click', () => {
                if (!posisiSaatIni) return;
                document.getElementById('input-aksi').value = btn.dataset.aksi;
                document.getElementById('input-lat').value = posisiSaatIni.latitude;
                document.getElementById('input-lng').value = posisiSaatIni.longitude;
                document.getElementById('form-absen').submit();
            });
        }
    </script>
    <?php require 'includes/footer.php'; ?>
</body>
</html>

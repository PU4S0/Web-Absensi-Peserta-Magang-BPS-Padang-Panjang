<?php
require_once 'includes/db.php';
require_once 'includes/upload_helper.php';

$error = "";
$success = "";

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nama = trim($_POST['nama']);
    $nim = trim($_POST['nim']);
    $jurusan = trim($_POST['jurusan']);
    $asal_universitas = trim($_POST['asal_universitas']);
    $mentor_id = $_POST['mentor_id'] ?? '';
    $tanggal_mulai = $_POST['tanggal_mulai'];
    $tanggal_selesai = $_POST['tanggal_selesai'];
    $username = trim($_POST['username']);
    $password = $_POST['password'];
    $konfirmasi = $_POST['konfirmasi_password'];

    if ($nama === '' || $nim === '' || $jurusan === '' || $asal_universitas === '' || $mentor_id === '' || $username === '' || $password === '') {
        $error = "Semua field wajib diisi.";
    } elseif (!ctype_digit($nim)) {
        $error = "NIM hanya boleh berisi angka.";
    } elseif ($password !== $konfirmasi) {
        $error = "Konfirmasi password tidak sama.";
    } elseif (strtotime($tanggal_selesai) < strtotime($tanggal_mulai)) {
        $error = "Tanggal selesai tidak boleh sebelum tanggal mulai.";
    } else {
        // Ambil nama & NIP mentor terpilih dari tabel pegawai
        $stmt = $conn->prepare("SELECT nama, nip FROM pegawai WHERE id = ?");
        $stmt->bind_param("i", $mentor_id);
        $stmt->execute();
        $mentor = $stmt->get_result()->fetch_assoc();
        $stmt->close();

        if (!$mentor) {
            $error = "Mentor yang dipilih tidak valid.";
        } else {
            // Cek username sudah dipakai atau belum
            $stmt = $conn->prepare("SELECT id FROM peserta WHERE username = ?");
            $stmt->bind_param("s", $username);
            $stmt->execute();
            if ($stmt->get_result()->num_rows > 0) {
                $error = "Username sudah dipakai, silakan pilih username lain.";
            }
            $stmt->close();
        }

        $foto_hasil = ['ok' => true, 'filename' => null];
        if (!$error) {
            $foto_hasil = proses_upload_foto_profil('foto');
            if (!$foto_hasil['ok']) {
                $error = $foto_hasil['error'];
            }
        }

        if (!$error) {
            $nama_mentor = $mentor['nama'];
            $nip_mentor = $mentor['nip'];
            $foto = $foto_hasil['filename'];
            $hashed = password_hash($password, PASSWORD_DEFAULT);
            $stmt = $conn->prepare("INSERT INTO peserta (nama, nim, jurusan, asal_universitas, nama_mentor, nip_mentor, foto, tanggal_mulai, tanggal_selesai, username, password) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
            $stmt->bind_param("sssssssssss", $nama, $nim, $jurusan, $asal_universitas, $nama_mentor, $nip_mentor, $foto, $tanggal_mulai, $tanggal_selesai, $username, $hashed);
            if ($stmt->execute()) {
                $success = "Pendaftaran berhasil! Silakan login menggunakan username dan password kamu.";
            } else {
                $error = "Gagal mendaftar, coba lagi.";
            }
            $stmt->close();
        }
    }
}

// Daftar mentor buat dropdown (cuma pegawai yang jabatannya "Mentor")
$daftar_mentor = $conn->query("SELECT id, nama, nip FROM pegawai WHERE jabatan = 'Mentor' ORDER BY nama ASC");
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Daftar Peserta Magang</title>
    <link rel="stylesheet" href="assets/css/style.css?v=10">
</head>
<body>
    <div class="page-center">
    <div class="auth-box auth-box-wide">
        <img src="assets/img/logo_bps.png?v=2" alt="Logo BPS" class="form-logo">
        <h2>Daftar Peserta Magang Baru</h2>

        <?php if ($error): ?>
            <script>document.addEventListener('DOMContentLoaded', function(){ tampilkanPopup(<?= json_encode($error) ?>, 'error'); });</script>
        <?php endif; ?>
        <?php if ($success): ?>
            <script>document.addEventListener('DOMContentLoaded', function(){ tampilkanPopup(<?= json_encode($success) ?>, 'success'); });</script>
            <p class="alert-success"><a href="login.php">Login di sini</a>.</p>
        <?php endif; ?>

        <?php if (!$success): ?>
        <form method="POST" enctype="multipart/form-data">
            <label>Foto Profil</label>
            <input type="file" name="foto" accept="image/png, image/jpeg, image/webp">
            <p class="muted" style="text-align:left; margin-top:4px;">Opsional. Format JPG/PNG/WEBP, ukuran bebas (otomatis dikecilkan).</p>

            <label>Nama Lengkap</label>
            <input type="text" name="nama" required value="<?= isset($nama) ? htmlspecialchars($nama) : '' ?>">

            <div class="form-row">
                <div>
                    <label>NIM</label>
                    <input type="text" name="nim" required inputmode="numeric" pattern="[0-9]+" title="NIM hanya boleh angka" oninput="this.value=this.value.replace(/[^0-9]/g,'')" value="<?= isset($nim) ? htmlspecialchars($nim) : '' ?>">
                </div>
                <div>
                    <label>Jurusan</label>
                    <input type="text" name="jurusan" required value="<?= isset($jurusan) ? htmlspecialchars($jurusan) : '' ?>">
                </div>
            </div>

            <label>Asal Universitas</label>
            <input type="text" name="asal_universitas" required value="<?= isset($asal_universitas) ? htmlspecialchars($asal_universitas) : '' ?>">

            <label>Nama Mentor</label>
            <select name="mentor_id" required>
                <option value="">-- Pilih Mentor --</option>
                <?php while ($m = $daftar_mentor->fetch_assoc()): ?>
                    <option value="<?= $m['id'] ?>" <?= (isset($mentor_id) && $mentor_id == $m['id']) ? 'selected' : '' ?>>
                        <?= htmlspecialchars($m['nama']) ?> (NIP. <?= htmlspecialchars($m['nip']) ?>)
                    </option>
                <?php endwhile; ?>
            </select>

            <div class="form-row">
                <div>
                    <label>Tanggal Mulai Magang</label>
                    <input type="date" name="tanggal_mulai" required value="<?= isset($tanggal_mulai) ? htmlspecialchars($tanggal_mulai) : '' ?>">
                </div>
                <div>
                    <label>Tanggal Selesai Magang</label>
                    <input type="date" name="tanggal_selesai" required value="<?= isset($tanggal_selesai) ? htmlspecialchars($tanggal_selesai) : '' ?>">
                </div>
            </div>

            <label>Username</label>
            <input type="text" name="username" required value="<?= isset($username) ? htmlspecialchars($username) : '' ?>">

            <label>Password</label>
            <input type="password" name="password" required>

            <label>Konfirmasi Password</label>
            <input type="password" name="konfirmasi_password" required>

            <button type="submit" class="btn-primary">Daftar</button>
        </form>
        <?php endif; ?>

        <p class="muted"><a href="login.php">Sudah punya akun? Login di sini</a></p>
    </div>
    </div>
    <?php require 'includes/footer.php'; ?>
</body>
</html>

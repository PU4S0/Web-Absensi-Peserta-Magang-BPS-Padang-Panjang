<?php
require_once 'includes/auth.php';
require_once 'includes/db.php';
require_once 'includes/upload_helper.php';
require_admin_login();

$edit_mode = isset($_GET['id']);
$peserta = ['nama' => '', 'nim' => '', 'jurusan' => '', 'asal_universitas' => '', 'nama_mentor' => '', 'nip_mentor' => '', 'foto' => null, 'tanggal_mulai' => '', 'tanggal_selesai' => '', 'username' => ''];
$error = "";

if ($edit_mode) {
    $id = (int)$_GET['id'];
    $stmt = $conn->prepare("SELECT * FROM peserta WHERE id = ?");
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $result = $stmt->get_result();
    if ($result->num_rows === 0) {
        header("Location: peserta_admin.php");
        exit;
    }
    $peserta = $result->fetch_assoc();
    $stmt->close();
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nama = trim($_POST['nama']);
    $nim = trim($_POST['nim']);
    $jurusan = trim($_POST['jurusan']);
    $asal_universitas = trim($_POST['asal_universitas']);
    $mentor_id = $_POST['mentor_id'] ?? '';
    $tanggal_mulai = $_POST['tanggal_mulai'];
    $tanggal_selesai = $_POST['tanggal_selesai'];
    $username = trim($_POST['username']);
    $password = $_POST['password']; // hanya diisi kalau mau set password saat tambah baru

    if ($nama === '' || $nim === '' || $jurusan === '' || $asal_universitas === '' || $mentor_id === '' || $username === '') {
        $error = "Nama, NIM, jurusan, asal universitas, mentor, dan username wajib diisi.";
    } elseif (!ctype_digit($nim)) {
        $error = "NIM hanya boleh berisi angka.";
    } elseif (strtotime($tanggal_selesai) < strtotime($tanggal_mulai)) {
        $error = "Tanggal selesai tidak boleh sebelum tanggal mulai.";
    } else {
        // Ambil nama & NIP mentor terpilih
        $stmt = $conn->prepare("SELECT nama, nip FROM pegawai WHERE id = ?");
        $stmt->bind_param("i", $mentor_id);
        $stmt->execute();
        $mentor = $stmt->get_result()->fetch_assoc();
        $stmt->close();

        if (!$mentor) {
            $error = "Mentor yang dipilih tidak valid.";
        }

        // Cek username dipakai peserta lain
        if (!$error) {
            $stmt = $conn->prepare("SELECT id FROM peserta WHERE username = ? AND id != ?");
            $cek_id = $edit_mode ? (int)$_GET['id'] : 0;
            $stmt->bind_param("si", $username, $cek_id);
            $stmt->execute();
            if ($stmt->get_result()->num_rows > 0) {
                $error = "Username sudah dipakai peserta lain.";
            }
            $stmt->close();
        }

        $foto_hasil = ['ok' => true, 'filename' => null];
        if (!$error) {
            $foto_hasil = proses_upload_foto_profil('foto');
            if (!$foto_hasil['ok']) {
                $error = $foto_hasil['error'];
            }
        }

        if (!$error && $edit_mode) {
            $id = (int)$_GET['id'];
            $nama_mentor = $mentor['nama'];
            $nip_mentor = $mentor['nip'];
            if ($foto_hasil['filename']) {
                hapus_foto_profil($peserta['foto']);
                $stmt = $conn->prepare("UPDATE peserta SET nama=?, nim=?, jurusan=?, asal_universitas=?, nama_mentor=?, nip_mentor=?, foto=?, tanggal_mulai=?, tanggal_selesai=?, username=? WHERE id=?");
                $stmt->bind_param("ssssssssssi", $nama, $nim, $jurusan, $asal_universitas, $nama_mentor, $nip_mentor, $foto_hasil['filename'], $tanggal_mulai, $tanggal_selesai, $username, $id);
            } else {
                $stmt = $conn->prepare("UPDATE peserta SET nama=?, nim=?, jurusan=?, asal_universitas=?, nama_mentor=?, nip_mentor=?, tanggal_mulai=?, tanggal_selesai=?, username=? WHERE id=?");
                $stmt->bind_param("sssssssssi", $nama, $nim, $jurusan, $asal_universitas, $nama_mentor, $nip_mentor, $tanggal_mulai, $tanggal_selesai, $username, $id);
            }
            $stmt->execute();
            $stmt->close();
            header("Location: peserta_admin.php?msg=" . urlencode("Data peserta berhasil diperbarui."));
            exit;
        } elseif (!$error && !$edit_mode) {
            if ($password === '') {
                $error = "Password wajib diisi untuk peserta baru.";
            } else {
                $nama_mentor = $mentor['nama'];
                $nip_mentor = $mentor['nip'];
                $hashed = password_hash($password, PASSWORD_DEFAULT);
                $foto = $foto_hasil['filename'];
                $stmt = $conn->prepare("INSERT INTO peserta (nama, nim, jurusan, asal_universitas, nama_mentor, nip_mentor, foto, tanggal_mulai, tanggal_selesai, username, password) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
                $stmt->bind_param("sssssssssss", $nama, $nim, $jurusan, $asal_universitas, $nama_mentor, $nip_mentor, $foto, $tanggal_mulai, $tanggal_selesai, $username, $hashed);
                $stmt->execute();
                $stmt->close();
                header("Location: peserta_admin.php?msg=" . urlencode("Peserta baru berhasil ditambahkan."));
                exit;
            }
        }

        // supaya form tetap terisi ulang kalau error
        $peserta = ['nama' => $nama, 'nim' => $nim, 'jurusan' => $jurusan, 'asal_universitas' => $asal_universitas, 'nama_mentor' => $mentor['nama'] ?? '', 'nip_mentor' => $mentor['nip'] ?? '', 'foto' => $peserta['foto'] ?? null, 'tanggal_mulai' => $tanggal_mulai, 'tanggal_selesai' => $tanggal_selesai, 'username' => $username];
        $peserta['mentor_id_terpilih'] = $mentor_id;
    }
}

$daftar_mentor = $conn->query("SELECT id, nama, nip FROM pegawai WHERE jabatan = 'Mentor' ORDER BY nama ASC");
// Kalau edit, cocokkan mentor yang sedang tersimpan (match lewat NIP, lebih unik dari nama)
$mentor_id_terpilih = $peserta['mentor_id_terpilih'] ?? null;
if ($mentor_id_terpilih === null && !empty($peserta['nip_mentor'])) {
    $stmt = $conn->prepare("SELECT id FROM pegawai WHERE nip = ?");
    $stmt->bind_param("s", $peserta['nip_mentor']);
    $stmt->execute();
    $r = $stmt->get_result()->fetch_assoc();
    $stmt->close();
    $mentor_id_terpilih = $r['id'] ?? null;
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title><?= $edit_mode ? 'Edit' : 'Tambah' ?> Peserta</title>
    <link rel="stylesheet" href="assets/css/style.css?v=10">
</head>
<body>
    <div class="page-center">
    <div class="auth-box auth-box-wide">
        <img src="assets/img/logo_bps.png?v=2" alt="Logo BPS" class="form-logo">
        <h2><?= $edit_mode ? 'Edit Peserta' : 'Tambah Peserta Baru' ?></h2>

        <?php if ($error): ?>
            <script>document.addEventListener('DOMContentLoaded', function(){ tampilkanPopup(<?= json_encode($error) ?>, 'error'); });</script>
        <?php endif; ?>

        <form method="POST" enctype="multipart/form-data">
            <?php $foto_url = url_foto_profil($peserta['foto'] ?? null); ?>
            <?php if ($foto_url): ?>
                <div style="text-align:center; margin-bottom:10px;">
                    <img src="<?= htmlspecialchars($foto_url) ?>" alt="Foto profil" style="width:80px; height:80px; border-radius:50%; object-fit:cover;">
                </div>
            <?php endif; ?>
            <label>Foto Profil <?= $edit_mode ? '(kosongkan kalau tidak diganti)' : '' ?></label>
            <input type="file" name="foto" accept="image/png, image/jpeg, image/webp">

            <label>Nama Lengkap</label>
            <input type="text" name="nama" required value="<?= htmlspecialchars($peserta['nama']) ?>">

            <div class="form-row">
                <div>
                    <label>NIM</label>
                    <input type="text" name="nim" required inputmode="numeric" pattern="[0-9]+" title="NIM hanya boleh angka" oninput="this.value=this.value.replace(/[^0-9]/g,'')" value="<?= htmlspecialchars($peserta['nim']) ?>">
                </div>
                <div>
                    <label>Jurusan</label>
                    <input type="text" name="jurusan" required value="<?= htmlspecialchars($peserta['jurusan']) ?>">
                </div>
            </div>

            <label>Asal Universitas</label>
            <input type="text" name="asal_universitas" required value="<?= htmlspecialchars($peserta['asal_universitas']) ?>">

            <label>Nama Mentor</label>
            <select name="mentor_id" required>
                <option value="">-- Pilih Mentor --</option>
                <?php while ($m = $daftar_mentor->fetch_assoc()): ?>
                    <option value="<?= $m['id'] ?>" <?= ($mentor_id_terpilih == $m['id']) ? 'selected' : '' ?>>
                        <?= htmlspecialchars($m['nama']) ?> (NIP. <?= htmlspecialchars($m['nip']) ?>)
                    </option>
                <?php endwhile; ?>
            </select>

            <div class="form-row">
                <div>
                    <label>Tanggal Mulai Magang</label>
                    <input type="date" name="tanggal_mulai" required value="<?= htmlspecialchars($peserta['tanggal_mulai']) ?>">
                </div>
                <div>
                    <label>Tanggal Selesai Magang</label>
                    <input type="date" name="tanggal_selesai" required value="<?= htmlspecialchars($peserta['tanggal_selesai']) ?>">
                </div>
            </div>

            <label>Username</label>
            <input type="text" name="username" required value="<?= htmlspecialchars($peserta['username']) ?>">

            <?php if (!$edit_mode): ?>
                <label>Password</label>
                <input type="password" name="password" required>
            <?php else: ?>
                <p class="muted">Untuk ganti password peserta ini, gunakan tombol "Reset Password" di halaman daftar peserta.</p>
            <?php endif; ?>

            <button type="submit" class="btn-primary"><?= $edit_mode ? 'Simpan Perubahan' : 'Tambah Peserta' ?></button>
        </form>
        <p class="muted"><a href="peserta_admin.php">&larr; Kembali ke Daftar Peserta</a></p>
    </div>
    </div>
    <?php require 'includes/footer.php'; ?>
</body>
</html>

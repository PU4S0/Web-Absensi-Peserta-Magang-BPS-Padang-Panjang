<?php
require_once 'includes/auth.php';
require_once 'includes/db.php';
require_once 'includes/config.php';
require_admin_login();

$jumlah_notif = jumlah_pengajuan_menunggu($conn);

$peserta_list = $conn->query("SELECT * FROM peserta ORDER BY nama ASC");
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Kelola Peserta Magang</title>
    <link rel="stylesheet" href="https://cdn.datatables.net/2.1.8/css/dataTables.dataTables.min.css">
    <link rel="stylesheet" href="https://cdn.datatables.net/buttons/3.0.1/css/buttons.dataTables.min.css">
    <link rel="stylesheet" href="https://cdn.datatables.net/select/2.0.0/css/select.dataTables.min.css">
    <link rel="stylesheet" href="assets/css/style.css?v=10">
</head>
<body>
    <div class="container container-wide">
        <div class="topbar">
            <div class="topbar-left">
                <img src="assets/img/logo_bps.png?v=2" alt="Logo BPS" class="topbar-logo">
                <h2>Kelola Peserta Magang</h2>
            </div>
            <div class="topbar-actions">
                <a href="admin_dashboard.php" class="btn-outline">&larr; Dashboard</a>
                <a href="admin_notifikasi.php" class="btn-outline notif-bell">
                    &#128276; Notifikasi
                    <?php if ($jumlah_notif > 0): ?><span class="notif-badge"><?= $jumlah_notif ?></span><?php endif; ?>
                </a>
                <a href="ganti_password_admin.php" class="btn-outline">Ganti Password</a>
                <a href="logout.php" class="btn-outline">Logout</a>
            </div>
        </div>

        <?php if (isset($_GET['msg'])): ?>
            <script>document.addEventListener('DOMContentLoaded', function(){ tampilkanPopup(<?= json_encode($_GET['msg']) ?>, 'success'); });</script>
        <?php endif; ?>

        <div class="card">
            <div class="card-header-row">
                <h3>Daftar Peserta</h3>
            </div>

            <!-- Toolbar aksi: New / Hapus Terpilih, mirip contoh DataTables Editor -->
            <div class="dt-toolbar">
                <a href="peserta_form.php" class="dt-toolbar-btn dt-toolbar-btn-primary">+ New</a>
                <button type="button" id="btn-hapus-terpilih" class="dt-toolbar-btn" disabled>Delete Selected</button>
                <span id="jumlah-terpilih" class="muted-inline" style="margin-left:6px;"></span>
            </div>

            <div class="dt-filter-bar">
                <div class="dt-filter-item">
                    <label>Cari Nama</label>
                    <input type="text" id="filter-nama" placeholder="Ketik nama...">
                </div>
                <div class="dt-filter-item">
                    <label>Status Magang</label>
                    <select id="filter-status">
                        <option value="">Semua</option>
                        <option value="Aktif">Aktif</option>
                        <option value="Tidak Aktif">Tidak Aktif</option>
                    </select>
                </div>
                <div class="dt-filter-item">
                    <label>Mulai Dari</label>
                    <input type="date" id="filter-dari">
                </div>
                <div class="dt-filter-item">
                    <label>Sampai</label>
                    <input type="date" id="filter-sampai">
                </div>
            </div>

            <table id="tabel-peserta" class="display" style="width:100%">
                <thead>
                <tr>
                    <th></th>
                    <th>Nama</th><th>NIM</th><th>Jurusan</th><th>Asal Universitas</th><th>Mentor</th><th>Mulai</th><th>Selesai</th><th>Status</th><th>Aksi</th><th>MulaiISO</th>
                </tr>
                </thead>
                <tbody>
                <?php while ($p = $peserta_list->fetch_assoc()): $st = status_peserta($p['tanggal_selesai']); ?>
                <tr data-id="<?= $p['id'] ?>">
                    <td></td>
                    <td><?= htmlspecialchars($p['nama']) ?></td>
                    <td><?= htmlspecialchars($p['nim']) ?></td>
                    <td><?= htmlspecialchars($p['jurusan']) ?></td>
                    <td><?= htmlspecialchars($p['asal_universitas']) ?></td>
                    <td><?= htmlspecialchars($p['nama_mentor']) ?></td>
                    <td><?= date('d M Y', strtotime($p['tanggal_mulai'])) ?></td>
                    <td><?= date('d M Y', strtotime($p['tanggal_selesai'])) ?></td>
                    <td><span class="pill-office <?= $st === 'Aktif' ? 'pill-aktif' : 'pill-tidak-aktif' ?>"><?= $st ?></span></td>
                    <td class="aksi-cell">
                        <a href="peserta_form.php?id=<?= $p['id'] ?>" class="btn-outline btn-sm">Edit</a>
                        <a href="peserta_reset_password.php?id=<?= $p['id'] ?>" class="btn-outline btn-sm">Reset Password</a>
                        <form method="POST" action="peserta_hapus.php" class="inline-form" onsubmit="return confirm('Hapus peserta ini beserta semua riwayat absensinya?');">
                            <input type="hidden" name="id" value="<?= $p['id'] ?>">
                            <button type="submit" class="btn-danger btn-sm">Hapus</button>
                        </form>
                    </td>
                    <td><?= $p['tanggal_mulai'] ?></td>
                </tr>
                <?php endwhile; ?>
                </tbody>
            </table>
        </div>
    </div>

    <!-- Form tersembunyi untuk kirim hapus massal -->
    <form id="form-hapus-massal" method="POST" action="peserta_hapus_massal.php" style="display:none;"></form>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
    <script src="https://cdn.datatables.net/2.1.8/js/dataTables.min.js"></script>
    <script src="https://cdn.datatables.net/buttons/3.0.1/js/dataTables.buttons.min.js"></script>
    <script src="https://cdn.datatables.net/buttons/3.0.1/js/buttons.html5.min.js"></script>
    <script src="https://cdn.datatables.net/buttons/3.0.1/js/buttons.print.min.js"></script>
    <script src="https://cdn.datatables.net/select/2.0.0/js/dataTables.select.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jszip/3.10.1/jszip.min.js"></script>
    <script>
        $(document).ready(function () {
            const tabel = $('#tabel-peserta').DataTable({
                order: [[1, 'asc']],
                pageLength: 10,
                dom: '<"dt-top"lfB>rt<"dt-bottom"ip>',
                select: { style: 'multi', selector: 'td:first-child' },
                columnDefs: [
                    { targets: 0, orderable: false, searchable: false, className: 'select-checkbox', data: null, defaultContent: '' },
                    { targets: 9, orderable: false, searchable: false },
                    { targets: 10, visible: false }
                ],
                buttons: [
                    { extend: 'copyHtml5', text: 'Copy', className: 'dt-btn' },
                    { extend: 'csvHtml5', text: 'CSV', className: 'dt-btn' },
                    { extend: 'excelHtml5', text: 'Excel', className: 'dt-btn' },
                    { extend: 'print', text: 'Print', className: 'dt-btn' }
                ],
                language: {
                    search: 'Cari:',
                    lengthMenu: 'Tampilkan _MENU_ baris',
                    info: 'Menampilkan _START_-_END_ dari _TOTAL_ peserta',
                    paginate: { previous: 'Sebelumnya', next: 'Berikutnya' },
                    zeroRecords: 'Tidak ada peserta yang cocok'
                }
            });

            function updateTombolHapus() {
                const jumlah = tabel.rows({ selected: true }).count();
                $('#btn-hapus-terpilih').prop('disabled', jumlah === 0);
                $('#jumlah-terpilih').text(jumlah > 0 ? jumlah + ' dipilih' : '');
            }
            tabel.on('select deselect', updateTombolHapus);

            $('#btn-hapus-terpilih').on('click', function () {
                const idTerpilih = tabel.rows({ selected: true }).nodes().toArray().map(tr => tr.dataset.id);
                if (idTerpilih.length === 0) return;
                if (!confirm('Hapus ' + idTerpilih.length + ' peserta terpilih beserta seluruh riwayat absensinya? Tindakan ini tidak bisa dibatalkan.')) return;

                const form = document.getElementById('form-hapus-massal');
                form.innerHTML = '';
                idTerpilih.forEach(id => {
                    const input = document.createElement('input');
                    input.type = 'hidden';
                    input.name = 'ids[]';
                    input.value = id;
                    form.appendChild(input);
                });
                form.submit();
            });

            $('#filter-nama').on('keyup', function () {
                tabel.column(1).search(this.value).draw();
            });

            $('#filter-status').on('change', function () {
                const val = this.value;
                tabel.column(8).search(val ? '^' + val + '$' : '', true, false).draw();
            });

            $.fn.dataTable.ext.search.push(function (settings, data) {
                if (settings.nTable.id !== 'tabel-peserta') return true;
                const dari = $('#filter-dari').val();
                const sampai = $('#filter-sampai').val();
                const tgl = data[10];
                if (dari && tgl < dari) return false;
                if (sampai && tgl > sampai) return false;
                return true;
            });
            $('#filter-dari, #filter-sampai').on('change', function () {
                tabel.draw();
            });
        });
    </script>
    <?php require 'includes/footer.php'; ?>
</body>
</html>

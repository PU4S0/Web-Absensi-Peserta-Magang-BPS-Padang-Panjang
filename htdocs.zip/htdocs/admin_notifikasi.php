<?php
require_once 'includes/auth.php';
require_once 'includes/db.php';
require_admin_login();

$menunggu = $conn->query("
    SELECT p.*, ps.nama AS nama_peserta
    FROM pengajuan p
    JOIN peserta ps ON ps.id = p.peserta_id
    WHERE p.status_pengajuan = 'menunggu'
    ORDER BY p.created_at ASC
");

$riwayat = $conn->query("
    SELECT p.*, ps.nama AS nama_peserta
    FROM pengajuan p
    JOIN peserta ps ON ps.id = p.peserta_id
    WHERE p.status_pengajuan != 'menunggu'
    ORDER BY p.diproses_at DESC
    LIMIT 200
");

function label_jenis($jenis) {
    return ['absen_manual' => 'Absen Manual', 'izin' => 'Izin', 'sakit' => 'Sakit'][$jenis] ?? $jenis;
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Notifikasi Pengajuan</title>
    <link rel="stylesheet" href="https://cdn.datatables.net/2.1.8/css/dataTables.dataTables.min.css">
    <link rel="stylesheet" href="assets/css/style.css?v=10">
</head>
<body>
    <div class="container container-wide">
        <div class="topbar">
            <div class="topbar-left">
                <img src="assets/img/logo_bps.png?v=2" alt="Logo BPS" class="topbar-logo">
                <h2>Notifikasi Pengajuan</h2>
            </div>
            <div class="topbar-actions">
                <a href="admin_dashboard.php" class="btn-outline">&larr; Dashboard</a>
                <a href="logout.php" class="btn-outline">Logout</a>
            </div>
        </div>

        <?php if (isset($_GET['msg'])): ?>
            <script>document.addEventListener('DOMContentLoaded', function(){ tampilkanPopup(<?= json_encode($_GET['msg']) ?>, 'success'); });</script>
        <?php endif; ?>

        <div class="card">
            <h3>Menunggu Persetujuan (<?= $menunggu->num_rows ?>)</h3>
            <table id="tabel-menunggu" class="display">
                <thead>
                <tr>
                    <th>Peserta</th><th>Tanggal</th><th>Jenis</th><th>Detail</th><th>Diajukan</th><th>Aksi</th>
                </tr>
                </thead>
                <tbody>
                <?php while ($row = $menunggu->fetch_assoc()): ?>
                <tr>
                    <td><?= htmlspecialchars($row['nama_peserta']) ?></td>
                    <td><?= date('d M Y', strtotime($row['tanggal'])) ?></td>
                    <td><span class="status-pill status-<?= $row['jenis'] === 'absen_manual' ? 'hadir' : $row['jenis'] ?>"><?= label_jenis($row['jenis']) ?></span></td>
                    <td>
                        <?php if ($row['jenis'] === 'absen_manual'): ?>
                            Masuk: <?= $row['jam_masuk_diajukan'] ?? '-' ?> &nbsp;|&nbsp; Pulang: <?= $row['jam_pulang_diajukan'] ?? '-' ?><br>
                        <?php endif; ?>
                        <span class="muted-inline"><?= htmlspecialchars($row['keterangan']) ?></span>
                    </td>
                    <td><?= date('d M Y H:i', strtotime($row['created_at'])) ?></td>
                    <td class="aksi-cell">
                        <form method="POST" action="proses_pengajuan.php" class="inline-form">
                            <input type="hidden" name="id" value="<?= $row['id'] ?>">
                            <input type="hidden" name="aksi" value="setujui">
                            <button type="submit" class="btn-approve" onclick="return confirm('Setujui pengajuan ini? Data akan otomatis masuk ke rekap absensi.');">Setujui</button>
                        </form>
                        <button type="button" class="btn-reject" onclick="tolakPengajuan(<?= $row['id'] ?>)">Tolak</button>
                    </td>
                </tr>
                <?php endwhile; ?>
                </tbody>
            </table>
        </div>

        <div class="card">
            <h3>Riwayat Pengajuan yang Sudah Diproses</h3>
            <table id="tabel-riwayat" class="display">
                <thead>
                <tr>
                    <th>Peserta</th><th>Tanggal</th><th>Jenis</th><th>Keterangan</th><th>Status</th><th>Catatan Admin</th><th>Diproses</th>
                </tr>
                </thead>
                <tbody>
                <?php while ($row = $riwayat->fetch_assoc()): ?>
                <tr>
                    <td><?= htmlspecialchars($row['nama_peserta']) ?></td>
                    <td><?= date('d M Y', strtotime($row['tanggal'])) ?></td>
                    <td><?= label_jenis($row['jenis']) ?></td>
                    <td><?= htmlspecialchars($row['keterangan']) ?></td>
                    <td><span class="status-pill status-pengajuan-<?= $row['status_pengajuan'] ?>"><?= ucfirst($row['status_pengajuan']) ?></span></td>
                    <td><?= htmlspecialchars($row['catatan_admin'] ?? '-') ?></td>
                    <td><?= $row['diproses_at'] ? date('d M Y H:i', strtotime($row['diproses_at'])) : '-' ?></td>
                </tr>
                <?php endwhile; ?>
                </tbody>
            </table>
        </div>
    </div>

    <!-- Form tersembunyi untuk aksi Tolak (perlu input catatan alasan) -->
    <div id="modal-tolak" class="modal-overlay" style="display:none;">
        <div class="modal-box">
            <h3>Tolak Pengajuan</h3>
            <form method="POST" action="proses_pengajuan.php">
                <input type="hidden" name="id" id="tolak-id">
                <input type="hidden" name="aksi" value="tolak">
                <label>Alasan Penolakan (opsional)</label>
                <textarea name="catatan" rows="3" placeholder="Contoh: Tidak ada bukti pendukung"></textarea>
                <div class="modal-actions">
                    <button type="button" class="btn-outline" onclick="tutupModalTolak()">Batal</button>
                    <button type="submit" class="btn-reject">Tolak Pengajuan</button>
                </div>
            </form>
        </div>
    </div>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
    <script src="https://cdn.datatables.net/2.1.8/js/dataTables.min.js"></script>
    <script>
        $(document).ready(function () {
            $('#tabel-menunggu').DataTable({ order: [], pageLength: 10 });
            $('#tabel-riwayat').DataTable({ order: [[6, 'desc']], pageLength: 10 });
        });

        function tolakPengajuan(id) {
            document.getElementById('tolak-id').value = id;
            document.getElementById('modal-tolak').style.display = 'flex';
        }
        function tutupModalTolak() {
            document.getElementById('modal-tolak').style.display = 'none';
        }
    </script>
    <?php require 'includes/footer.php'; ?>
</body>
</html>

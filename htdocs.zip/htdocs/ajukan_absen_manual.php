<?php
require_once 'includes/auth.php';
require_once 'includes/db.php';
require_peserta_login();

$peserta_id = $_SESSION['peserta_id'];
$error = "";
$success = "";

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $tanggal = $_POST['tanggal'];
    $jam_masuk = $_POST['jam_masuk'] ?: null;
    $jam_pulang = $_POST['jam_pulang'] ?: null;
    $keterangan = trim($_POST['keterangan']);

    if ($keterangan === '') {
        $error = "Keterangan wajib diisi (jelaskan kendala absennya apa).";
    } elseif (!$jam_masuk && !$jam_pulang) {
        $error = "Isi minimal salah satu: jam masuk atau jam pulang.";
    } elseif (strtotime($tanggal) > strtotime(date('Y-m-d'))) {
        $error = "Tidak bisa mengajukan absen manual untuk tanggal yang belum terjadi.";
    } elseif (strtotime($tanggal) < strtotime(date('Y-m-d', strtotime('-7 days')))) {
        $error = "Pengajuan absen manual cuma bisa untuk maksimal 7 hari ke belakang.";
    } elseif ($tanggal === date('Y-m-d') && (($jam_masuk && $jam_masuk > date('H:i')) || ($jam_pulang && $jam_pulang > date('H:i')))) {
        $error = "Jam yang diajukan belum terlewati hari ini. Tunggu sampai jam tersebut baru bisa mengajukan.";
    } else {
        // Cek apakah sudah ada absensi hadir lengkap di tanggal itu
        $stmt = $conn->prepare("SELECT jam_masuk, jam_pulang FROM absensi WHERE peserta_id = ? AND tanggal = ?");
        $stmt->bind_param("is", $peserta_id, $tanggal);
        $stmt->execute();
        $existing = $stmt->get_result()->fetch_assoc();
        $stmt->close();

        if ($existing && $existing['jam_masuk'] && $existing['jam_pulang']) {
            $error = "Absensi tanggal ini sudah lengkap, tidak perlu ajukan absen manual.";
        } else {
            $stmt = $conn->prepare("
                INSERT INTO pengajuan (peserta_id, tanggal, jenis, jam_masuk_diajukan, jam_pulang_diajukan, keterangan)
                VALUES (?, ?, 'absen_manual', ?, ?, ?)
            ");
            $stmt->bind_param("issss", $peserta_id, $tanggal, $jam_masuk, $jam_pulang, $keterangan);
            if ($stmt->execute()) {
                $success = "Pengajuan absen manual untuk tanggal " . date('d M Y', strtotime($tanggal)) . " berhasil dikirim, menunggu persetujuan admin.";
            } else {
                $error = "Gagal mengirim pengajuan, coba lagi.";
            }
            $stmt->close();
        }
    }
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Ajukan Absen Manual</title>
    <link rel="stylesheet" href="assets/css/style.css?v=10">
</head>
<body>
    <div class="container">
        <div class="topbar">
            <div class="topbar-left">
                <img src="assets/img/logo_bps.png?v=2" alt="Logo BPS" class="topbar-logo">
                <h2>Ajukan Absen Manual</h2>
            </div>
            <a href="dashboard_peserta.php" class="btn-outline">&larr; Kembali</a>
        </div>

        <div class="card">
            <p class="muted" style="text-align:left; margin-top:0;">
                Gunakan form ini kalau kamu <strong>sudah hadir di kantor sesuai jam</strong> tapi terkendala
                saat absen normal (misalnya GPS error, lupa absen, atau kendala lokasi). Isi jam yang sesuai
                dengan kenyataan, pengajuan ini akan ditinjau dan disetujui/ditolak oleh admin.
            </p>

            <?php if ($error): ?>
                <script>document.addEventListener('DOMContentLoaded', function(){ tampilkanPopup(<?= json_encode($error) ?>, 'error'); });</script>
            <?php endif; ?>
            <?php if ($success): ?>
                <script>document.addEventListener('DOMContentLoaded', function(){ tampilkanPopup(<?= json_encode($success) ?>, 'success'); });</script>
            <?php endif; ?>

            <form method="POST">
                <label>Tanggal</label>
                <input type="date" name="tanggal" required max="<?= date('Y-m-d') ?>" min="<?= date('Y-m-d', strtotime('-7 days')) ?>" value="<?= date('Y-m-d') ?>">
                <p class="muted" style="text-align:left; margin-top:4px;">Maksimal 7 hari ke belakang dari hari ini.</p>

                <div class="form-row">
                    <div>
                        <label>Jam Masuk (kalau perlu diajukan)</label>
                        <input type="time" name="jam_masuk">
                    </div>
                    <div>
                        <label>Jam Pulang (kalau perlu diajukan)</label>
                        <input type="time" name="jam_pulang">
                    </div>
                </div>

                <label>Keterangan / Alasan</label>
                <textarea name="keterangan" rows="4" required placeholder="Contoh: Sudah di kantor jam 08.00 tapi GPS tidak akurat sehingga absen masuk gagal"></textarea>

                <button type="submit" class="btn-primary">Kirim Pengajuan</button>
            </form>
        </div>
    </div>
    <?php require 'includes/footer.php'; ?>
</body>
</html>

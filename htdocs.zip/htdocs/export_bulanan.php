<?php
require_once 'includes/auth.php';
require_once 'includes/db.php';
require_once 'includes/config.php';
require_once 'includes/export_helper.php';
require_admin_login();

$bulan_filter = $_GET['bulan'] ?? date('Y-m');

$stmt = $conn->prepare("
    SELECT p.id, p.nama, p.tanggal_mulai, p.tanggal_selesai,
           SUM(CASE WHEN a.status = 'hadir' THEN 1 ELSE 0 END) AS jumlah_hadir,
           SUM(CASE WHEN a.status = 'izin' THEN 1 ELSE 0 END) AS jumlah_izin,
           SUM(CASE WHEN a.status = 'sakit' THEN 1 ELSE 0 END) AS jumlah_sakit,
           SUM(CASE WHEN a.jam_masuk IS NOT NULL AND a.jam_pulang IS NOT NULL THEN 1 ELSE 0 END) AS lengkap
    FROM peserta p
    LEFT JOIN absensi a ON a.peserta_id = p.id AND DATE_FORMAT(a.tanggal, '%Y-%m') = ?
    GROUP BY p.id
    ORDER BY p.nama ASC
");
$stmt->bind_param("s", $bulan_filter);
$stmt->execute();
$data_mentah = $stmt->get_result();
$stmt->close();

$awal_bulan = $bulan_filter . '-01';
$akhir_bulan = date('Y-m-t', strtotime($awal_bulan));
$data = [];
while ($r = $data_mentah->fetch_assoc()) {
    $r['tidak_hadir'] = count(tanggal_tidak_hadir($conn, $r['id'], $r['tanggal_mulai'], $r['tanggal_selesai'], $awal_bulan, $akhir_bulan));
    $data[] = $r;
}

// Catatan kegiatan semua peserta pada bulan tersebut
$stmt = $conn->prepare("
    SELECT p.nama, k.tanggal, k.deskripsi
    FROM kegiatan_harian k
    JOIN peserta p ON p.id = k.peserta_id
    WHERE k.tanggal BETWEEN ? AND ?
    ORDER BY p.nama ASC, k.tanggal ASC, k.created_at ASC
");
$stmt->bind_param("ss", $awal_bulan, $akhir_bulan);
$stmt->execute();
$kegiatan = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
$stmt->close();

$filename = "rekap_absen_bulanan_" . $bulan_filter . ".xls";
$nama_bulan = date('F Y', strtotime($bulan_filter . '-01'));

header("Content-Type: application/vnd.ms-excel; charset=utf-8");
header("Content-Disposition: attachment; filename=\"$filename\"");
echo "\xEF\xBB\xBF";
echo buka_dokumen_excel();
echo kop_surat('REKAP ABSENSI BULANAN PESERTA MAGANG', 'Bulan: ' . $nama_bulan, 8);
?>
<table border="1" style="border-collapse:collapse; width:100%; table-layout:fixed;">
    <colgroup>
        <col style="width:40px;"><col><col style="width:70px;"><col style="width:60px;"><col style="width:60px;"><col style="width:90px;"><col style="width:90px;"><col style="width:100px;">
    </colgroup>
    <tr style="background:#f0f0f0;">
        <th>No</th><th>Nama</th><th>Hadir</th><th>Izin</th><th>Sakit</th><th>Tidak Hadir</th><th>Absen Lengkap</th><th>Status Magang</th>
    </tr>
    <?php $no = 1; foreach ($data as $row): $st = status_peserta($row['tanggal_selesai']); ?>
    <tr>
        <td style="text-align:center;"><?= $no++ ?></td>
        <td><?= htmlspecialchars($row['nama']) ?></td>
        <td style="text-align:center;"><?= (int)$row['jumlah_hadir'] ?></td>
        <td style="text-align:center;"><?= (int)$row['jumlah_izin'] ?></td>
        <td style="text-align:center;"><?= (int)$row['jumlah_sakit'] ?></td>
        <td style="text-align:center;"><?= (int)$row['tidak_hadir'] ?></td>
        <td style="text-align:center;"><?= (int)$row['lengkap'] ?></td>
        <td style="text-align:center;"><?= $st ?></td>
    </tr>
    <?php endforeach; ?>
</table>

<table style="border-collapse:collapse; font-size:12px; margin-top:14px;">
    <tr><td style="border:none; padding:2px 0;"><strong>Catatan Kegiatan Harian</strong></td></tr>
</table>
<table border="1" style="border-collapse:collapse; width:100%; table-layout:fixed;">
    <colgroup>
        <col style="width:40px;"><col><col style="width:70px;"><col style="width:60px;"><col style="width:60px;"><col style="width:90px;"><col style="width:90px;"><col style="width:100px;">
    </colgroup>
    <tr style="background:#f0f0f0;">
        <th>No</th><th>Nama</th><th colspan="2">Tanggal</th><th colspan="4" style="text-align:left;">Kegiatan</th>
    </tr>
    <?php if ($kegiatan): $nk = 1; foreach ($kegiatan as $k): ?>
    <tr>
        <td style="text-align:center; vertical-align:top;"><?= $nk++ ?></td>
        <td style="vertical-align:top;"><?= htmlspecialchars($k['nama']) ?></td>
        <td colspan="2" style="vertical-align:top;"><?= date('d F Y', strtotime($k['tanggal'])) ?></td>
        <td colspan="4" style="vertical-align:top;"><?= nl2br(htmlspecialchars($k['deskripsi'])) ?></td>
    </tr>
    <?php endforeach; else: ?>
    <tr><td>&nbsp;</td><td>&nbsp;</td><td colspan="2">&nbsp;</td><td colspan="4">&nbsp;</td></tr>
    <?php endif; ?>
</table>

<?= blok_tanda_tangan(8) ?>
<?php echo tutup_dokumen_excel(); ?>

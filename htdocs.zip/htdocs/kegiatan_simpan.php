<?php
require_once 'includes/auth.php';
require_once 'includes/db.php';
require_peserta_login();

$peserta_id = $_SESSION['peserta_id'];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $aksi = $_POST['aksi'] ?? 'tambah';

    if ($aksi === 'tambah') {
        $deskripsi = trim($_POST['deskripsi'] ?? '');
        if ($deskripsi === '') {
            header("Location: dashboard_peserta.php?kegiatan=kosong#bagian-kegiatan");
            exit;
        }
        $tanggal = date('Y-m-d'); // selalu tanggal hari ini
        $stmt = $conn->prepare("INSERT INTO kegiatan_harian (peserta_id, tanggal, deskripsi) VALUES (?, ?, ?)");
        $stmt->bind_param("iss", $peserta_id, $tanggal, $deskripsi);
        $stmt->execute();
        $stmt->close();
        header("Location: dashboard_peserta.php?kegiatan=ok#bagian-kegiatan");
        exit;
    } elseif ($aksi === 'edit') {
        $id = (int)($_POST['id'] ?? 0);
        $deskripsi = trim($_POST['deskripsi'] ?? '');
        if ($deskripsi === '') {
            header("Location: dashboard_peserta.php?kegiatan=kosong#bagian-kegiatan");
            exit;
        }
        // Cuma boleh edit catatan milik sendiri dan yang dibuat hari ini
        $hari_ini = date('Y-m-d');
        $stmt = $conn->prepare("UPDATE kegiatan_harian SET deskripsi = ? WHERE id = ? AND peserta_id = ? AND tanggal = ?");
        $stmt->bind_param("siis", $deskripsi, $id, $peserta_id, $hari_ini);
        $stmt->execute();
        $stmt->close();
        header("Location: dashboard_peserta.php?kegiatan=edit#bagian-kegiatan");
        exit;
    } elseif ($aksi === 'hapus') {
        $id = (int)($_POST['id'] ?? 0);
        // Cuma boleh hapus catatan milik sendiri
        $stmt = $conn->prepare("DELETE FROM kegiatan_harian WHERE id = ? AND peserta_id = ?");
        $stmt->bind_param("ii", $id, $peserta_id);
        $stmt->execute();
        $stmt->close();
        header("Location: dashboard_peserta.php?kegiatan=hapus#bagian-kegiatan");
        exit;
    }
}

header("Location: dashboard_peserta.php");
exit;

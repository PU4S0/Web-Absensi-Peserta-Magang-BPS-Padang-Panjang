<?php
require_once 'includes/auth.php';
require_once 'includes/db.php';
require_admin_login();

if ($_SERVER['REQUEST_METHOD'] !== 'POST' || !isset($_POST['id']) || !isset($_POST['aksi'])) {
    header("Location: admin_notifikasi.php");
    exit;
}

$id = (int)$_POST['id'];
$aksi = $_POST['aksi']; // setujui | tolak

$stmt = $conn->prepare("SELECT * FROM pengajuan WHERE id = ? AND status_pengajuan = 'menunggu'");
$stmt->bind_param("i", $id);
$stmt->execute();
$pengajuan = $stmt->get_result()->fetch_assoc();
$stmt->close();

if (!$pengajuan) {
    header("Location: admin_notifikasi.php?msg=" . urlencode("Pengajuan tidak ditemukan atau sudah diproses."));
    exit;
}

if ($aksi === 'setujui') {
    $peserta_id = $pengajuan['peserta_id'];
    $tanggal = $pengajuan['tanggal'];

    if ($pengajuan['jenis'] === 'absen_manual') {
        // Masukkan/update ke tabel absensi sebagai hadir, hanya isi kolom yang diajukan
        $stmt = $conn->prepare("
            INSERT INTO absensi (peserta_id, tanggal, jam_masuk, jam_pulang, status, keterangan)
            VALUES (?, ?, ?, ?, 'hadir', ?)
            ON DUPLICATE KEY UPDATE
                jam_masuk = COALESCE(VALUES(jam_masuk), jam_masuk),
                jam_pulang = COALESCE(VALUES(jam_pulang), jam_pulang),
                status = 'hadir',
                keterangan = VALUES(keterangan)
        ");
        $ket = "Absen manual disetujui admin: " . $pengajuan['keterangan'];
        $stmt->bind_param("issss", $peserta_id, $tanggal, $pengajuan['jam_masuk_diajukan'], $pengajuan['jam_pulang_diajukan'], $ket);
        $stmt->execute();
        $stmt->close();
    } else {
        // izin / sakit
        $stmt = $conn->prepare("
            INSERT INTO absensi (peserta_id, tanggal, status, keterangan)
            VALUES (?, ?, ?, ?)
            ON DUPLICATE KEY UPDATE status = VALUES(status), keterangan = VALUES(keterangan)
        ");
        $stmt->bind_param("isss", $peserta_id, $tanggal, $pengajuan['jenis'], $pengajuan['keterangan']);
        $stmt->execute();
        $stmt->close();
    }

    $stmt = $conn->prepare("UPDATE pengajuan SET status_pengajuan = 'disetujui', diproses_at = NOW() WHERE id = ?");
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $stmt->close();

    header("Location: admin_notifikasi.php?msg=" . urlencode("Pengajuan berhasil disetujui."));
    exit;
} elseif ($aksi === 'tolak') {
    $catatan = trim($_POST['catatan'] ?? '');
    $stmt = $conn->prepare("UPDATE pengajuan SET status_pengajuan = 'ditolak', catatan_admin = ?, diproses_at = NOW() WHERE id = ?");
    $stmt->bind_param("si", $catatan, $id);
    $stmt->execute();
    $stmt->close();

    header("Location: admin_notifikasi.php?msg=" . urlencode("Pengajuan ditolak."));
    exit;
}

header("Location: admin_notifikasi.php");
exit;

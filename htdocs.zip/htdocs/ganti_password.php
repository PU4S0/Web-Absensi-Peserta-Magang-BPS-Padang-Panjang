<?php
require_once 'includes/auth.php';
require_once 'includes/db.php';
require_peserta_login();

$peserta_id = $_SESSION['peserta_id'];
$error = "";
$success = "";

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $password_lama = $_POST['password_lama'];
    $password_baru = $_POST['password_baru'];
    $konfirmasi = $_POST['konfirmasi_password'];

    $stmt = $conn->prepare("SELECT password FROM peserta WHERE id = ?");
    $stmt->bind_param("i", $peserta_id);
    $stmt->execute();
    $row = $stmt->get_result()->fetch_assoc();
    $stmt->close();

    if (!password_verify($password_lama, $row['password'])) {
        $error = "Password lama salah.";
    } elseif (strlen($password_baru) < 6) {
        $error = "Password baru minimal 6 karakter.";
    } elseif ($password_baru !== $konfirmasi) {
        $error = "Konfirmasi password baru tidak sama.";
    } else {
        $hashed = password_hash($password_baru, PASSWORD_DEFAULT);
        $stmt = $conn->prepare("UPDATE peserta SET password = ? WHERE id = ?");
        $stmt->bind_param("si", $hashed, $peserta_id);
        $stmt->execute();
        $stmt->close();
        $success = "Password berhasil diganti.";
    }
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Ganti Password</title>
    <link rel="stylesheet" href="assets/css/style.css?v=10">
</head>
<body>
    <div class="page-center">
    <div class="auth-box">
        <img src="assets/img/logo_bps.png?v=2" alt="Logo BPS" class="form-logo">
        <h2>Ganti Password</h2>

        <?php if ($error): ?>
            <script>document.addEventListener('DOMContentLoaded', function(){ tampilkanPopup(<?= json_encode($error) ?>, 'error'); });</script>
        <?php endif; ?>
        <?php if ($success): ?>
            <script>document.addEventListener('DOMContentLoaded', function(){ tampilkanPopup(<?= json_encode($success) ?>, 'success'); });</script>
        <?php endif; ?>

        <form method="POST">
            <label>Password Lama</label>
            <input type="password" name="password_lama" required>
            <label>Password Baru</label>
            <input type="password" name="password_baru" required>
            <label>Konfirmasi Password Baru</label>
            <input type="password" name="konfirmasi_password" required>
            <button type="submit" class="btn-primary">Simpan</button>
        </form>
        <p class="muted"><a href="dashboard_peserta.php">&larr; Kembali ke Dashboard</a></p>
    </div>
    </div>
    <?php require 'includes/footer.php'; ?>
</body>
</html>

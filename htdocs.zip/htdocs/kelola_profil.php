<?php
require_once 'includes/auth.php';
require_once 'includes/db.php';
require_once 'includes/upload_helper.php';
require_peserta_login();

$peserta_id = $_SESSION['peserta_id'];
$error = "";
$success = "";

$stmt = $conn->prepare("SELECT * FROM peserta WHERE id = ?");
$stmt->bind_param("i", $peserta_id);
$stmt->execute();
$peserta = $stmt->get_result()->fetch_assoc();
$stmt->close();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $aksi = $_POST['aksi'] ?? '';

    if ($aksi === 'update_profil') {
        $nama = trim($_POST['nama']);
        $nim = trim($_POST['nim']);
        $jurusan = trim($_POST['jurusan']);
        $asal_universitas = trim($_POST['asal_universitas']);
        $mentor_id = $_POST['mentor_id'] ?? '';
        $username = trim($_POST['username']);

        if ($nama === '' || $nim === '' || $jurusan === '' || $asal_universitas === '' || $mentor_id === '' || $username === '') {
            $error = "Semua field wajib diisi.";
        } elseif (!ctype_digit($nim)) {
            $error = "NIM hanya boleh berisi angka.";
        } else {
            $stmt = $conn->prepare("SELECT nama, nip FROM pegawai WHERE id = ?");
            $stmt->bind_param("i", $mentor_id);
            $stmt->execute();
            $mentor = $stmt->get_result()->fetch_assoc();
            $stmt->close();

            if (!$mentor) {
                $error = "Mentor yang dipilih tidak valid.";
            } else {
                $stmt = $conn->prepare("SELECT id FROM peserta WHERE username = ? AND id != ?");
                $stmt->bind_param("si", $username, $peserta_id);
                $stmt->execute();
                if ($stmt->get_result()->num_rows > 0) {
                    $error = "Username sudah dipakai peserta lain.";
                }
                $stmt->close();
            }

            $foto_hasil = ['ok' => true, 'filename' => null];
            if (!$error) {
                $foto_hasil = proses_upload_foto_profil('foto');
                if (!$foto_hasil['ok']) {
                    $error = $foto_hasil['error'];
                }
            }

            if (!$error) {
                $nama_mentor = $mentor['nama'];
                $nip_mentor = $mentor['nip'];

                if ($foto_hasil['filename']) {
                    hapus_foto_profil($peserta['foto']);
                    $stmt = $conn->prepare("UPDATE peserta SET nama=?, nim=?, jurusan=?, asal_universitas=?, nama_mentor=?, nip_mentor=?, foto=?, username=? WHERE id=?");
                    $stmt->bind_param("ssssssssi", $nama, $nim, $jurusan, $asal_universitas, $nama_mentor, $nip_mentor, $foto_hasil['filename'], $username, $peserta_id);
                } else {
                    $stmt = $conn->prepare("UPDATE peserta SET nama=?, nim=?, jurusan=?, asal_universitas=?, nama_mentor=?, nip_mentor=?, username=? WHERE id=?");
                    $stmt->bind_param("sssssssi", $nama, $nim, $jurusan, $asal_universitas, $nama_mentor, $nip_mentor, $username, $peserta_id);
                }
                $stmt->execute();
                $stmt->close();

                $_SESSION['peserta_nama'] = $nama; // biar nama di header dashboard ikut ke-update
                $success = "Profil berhasil diperbarui.";

                $stmt = $conn->prepare("SELECT * FROM peserta WHERE id = ?");
                $stmt->bind_param("i", $peserta_id);
                $stmt->execute();
                $peserta = $stmt->get_result()->fetch_assoc();
                $stmt->close();
            }
        }
    } elseif ($aksi === 'ganti_password') {
        $password_lama = $_POST['password_lama'];
        $password_baru = $_POST['password_baru'];
        $konfirmasi = $_POST['konfirmasi_password'];

        if (!password_verify($password_lama, $peserta['password'])) {
            $error = "Password lama salah.";
        } elseif (strlen($password_baru) < 6) {
            $error = "Password baru minimal 6 karakter.";
        } elseif ($password_baru !== $konfirmasi) {
            $error = "Konfirmasi password baru tidak sama.";
        } else {
            $hashed = password_hash($password_baru, PASSWORD_DEFAULT);
            $stmt = $conn->prepare("UPDATE peserta SET password = ? WHERE id = ?");
            $stmt->bind_param("si", $hashed, $peserta_id);
            $stmt->execute();
            $stmt->close();
            $success = "Password berhasil diganti.";
        }
    }
}

$daftar_mentor = $conn->query("SELECT id, nama, nip FROM pegawai WHERE jabatan = 'Mentor' ORDER BY nama ASC");
$stmt = $conn->prepare("SELECT id FROM pegawai WHERE nip = ?");
$stmt->bind_param("s", $peserta['nip_mentor']);
$stmt->execute();
$r = $stmt->get_result()->fetch_assoc();
$stmt->close();
$mentor_id_terpilih = $r['id'] ?? null;

$foto_url = url_foto_profil($peserta['foto']);
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Kelola Profil</title>
    <link rel="stylesheet" href="assets/css/style.css?v=10">
</head>
<body>
    <div class="container">
        <div class="topbar">
            <div class="topbar-left">
                <img src="assets/img/logo_bps.png?v=2" alt="Logo BPS" class="topbar-logo">
                <h2>Kelola Profil</h2>
            </div>
            <a href="dashboard_peserta.php" class="btn-outline">&larr; Kembali</a>
        </div>

        <?php if ($error): ?>
            <script>document.addEventListener('DOMContentLoaded', function(){ tampilkanPopup(<?= json_encode($error) ?>, 'error'); });</script>
        <?php endif; ?>
        <?php if ($success): ?>
            <script>document.addEventListener('DOMContentLoaded', function(){ tampilkanPopup(<?= json_encode($success) ?>, 'success'); });</script>
        <?php endif; ?>

        <div class="card">
            <h3>Foto &amp; Data Diri</h3>
            <form method="POST" enctype="multipart/form-data">
                <input type="hidden" name="aksi" value="update_profil">

                <div style="text-align:center; margin-bottom:14px;">
                    <?php if ($foto_url): ?>
                        <img src="<?= htmlspecialchars($foto_url) ?>" alt="Foto profil" style="width:96px; height:96px; border-radius:50%; object-fit:cover; border:3px solid #e5e7eb;">
                    <?php else: ?>
                        <div class="avatar-circle" style="width:96px; height:96px; font-size:32px; background:#2563eb; color:#fff; margin:0 auto;">
                            <?= strtoupper(substr($peserta['nama'], 0, 1)) ?>
                        </div>
                    <?php endif; ?>
                </div>

                <label>Ganti Foto Profil</label>
                <input type="file" name="foto" accept="image/png, image/jpeg, image/webp">
                <p class="muted" style="text-align:left; margin-top:4px;">Kosongkan kalau tidak mau ganti foto. Format JPG/PNG/WEBP, maksimal 2MB.</p>

                <label>Nama Lengkap</label>
                <input type="text" name="nama" required value="<?= htmlspecialchars($peserta['nama']) ?>">

                <div class="form-row">
                    <div>
                        <label>NIM</label>
                        <input type="text" name="nim" required inputmode="numeric" pattern="[0-9]+" title="NIM hanya boleh angka" oninput="this.value=this.value.replace(/[^0-9]/g,'')" value="<?= htmlspecialchars($peserta['nim']) ?>">
                    </div>
                    <div>
                        <label>Jurusan</label>
                        <input type="text" name="jurusan" required value="<?= htmlspecialchars($peserta['jurusan']) ?>">
                    </div>
                </div>

                <label>Asal Universitas</label>
                <input type="text" name="asal_universitas" required value="<?= htmlspecialchars($peserta['asal_universitas']) ?>">

                <label>Nama Mentor</label>
                <select name="mentor_id" required>
                    <option value="">-- Pilih Mentor --</option>
                    <?php while ($m = $daftar_mentor->fetch_assoc()): ?>
                        <option value="<?= $m['id'] ?>" <?= ($mentor_id_terpilih == $m['id']) ? 'selected' : '' ?>>
                            <?= htmlspecialchars($m['nama']) ?> (NIP. <?= htmlspecialchars($m['nip']) ?>)
                        </option>
                    <?php endwhile; ?>
                </select>

                <label>Username</label>
                <input type="text" name="username" required value="<?= htmlspecialchars($peserta['username']) ?>">

                <p class="muted" style="text-align:left;">Tanggal mulai/selesai magang diatur oleh admin, tidak bisa diubah sendiri.</p>

                <button type="submit" class="btn-primary">Simpan Perubahan</button>
            </form>
        </div>

        <div class="card">
            <h3>Ganti Password</h3>
            <form method="POST">
                <input type="hidden" name="aksi" value="ganti_password">
                <label>Password Lama</label>
                <input type="password" name="password_lama" required>
                <label>Password Baru</label>
                <input type="password" name="password_baru" required>
                <label>Konfirmasi Password Baru</label>
                <input type="password" name="konfirmasi_password" required>
                <button type="submit" class="btn-primary">Ganti Password</button>
            </form>
        </div>
    </div>
    <?php require 'includes/footer.php'; ?>
</body>
</html>

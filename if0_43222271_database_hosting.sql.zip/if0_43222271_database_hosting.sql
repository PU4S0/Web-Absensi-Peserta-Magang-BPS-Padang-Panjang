-- phpMyAdmin SQL Dump
-- version 4.9.0.1
-- https://www.phpmyadmin.net/
--
-- Host: sql107.infinityfree.com
-- Waktu pembuatan: 01 Nov 2026 pada 20.50
-- Versi server: 11.4.13-MariaDB
-- Versi PHP: 7.2.22

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `if0_43222271_database_hosting`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `absensi`
--

CREATE TABLE `absensi` (
  `id` int(11) NOT NULL,
  `peserta_id` int(11) NOT NULL,
  `tanggal` date NOT NULL,
  `jam_masuk` time DEFAULT NULL,
  `jam_pulang` time DEFAULT NULL,
  `lat_masuk` decimal(10,7) DEFAULT NULL,
  `lng_masuk` decimal(10,7) DEFAULT NULL,
  `lat_pulang` decimal(10,7) DEFAULT NULL,
  `lng_pulang` decimal(10,7) DEFAULT NULL,
  `status` enum('hadir','izin','sakit','alpa') NOT NULL DEFAULT 'hadir',
  `keterangan` text DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data untuk tabel `absensi`
--

INSERT INTO `absensi` (`id`, `peserta_id`, `tanggal`, `jam_masuk`, `jam_pulang`, `lat_masuk`, `lng_masuk`, `lat_pulang`, `lng_pulang`, `status`, `keterangan`) VALUES
(1, 1, '2026-10-20', '13:32:20', '15:04:23', '-0.4661039', '100.3833214', '-0.4657149', '100.3834714', 'hadir', NULL),
(2, 1, '2026-10-21', '11:25:24', '14:55:25', '-0.4657200', '100.3834563', '-0.4657211', '100.3834450', 'hadir', NULL),
(3, 1, '2026-10-16', NULL, NULL, NULL, NULL, NULL, NULL, 'sakit', 'testing sakit'),
(4, 1, '2026-10-14', NULL, NULL, NULL, NULL, NULL, NULL, 'izin', 'testing izin'),
(5, 1, '2026-10-27', '07:52:02', '08:11:54', '-0.4657102', '100.3834785', '-0.4661397', '100.3833178', 'hadir', NULL),
(6, 1, '2026-10-28', '09:21:55', NULL, '-0.4657164', '100.3834340', NULL, NULL, 'hadir', NULL),
(7, 2, '2026-10-28', '09:23:35', '09:27:08', '-0.4657157', '100.3834160', '-0.4657157', '100.3834160', 'hadir', NULL);

-- --------------------------------------------------------

--
-- Struktur dari tabel `admin`
--

CREATE TABLE `admin` (
  `id` int(11) NOT NULL,
  `nama` varchar(100) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp()
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data untuk tabel `admin`
--

INSERT INTO `admin` (`id`, `nama`, `username`, `password`, `created_at`) VALUES
(1, 'Admin BPS Kota Padang Panjang', 'admin', '$2b$10$s3Hw2XZN.zk0lzs8N6f6cO2a6Oc/BTQR4mwz96Lvw2HT.U6XjEQo2', '2026-10-20 04:26:14');

-- --------------------------------------------------------

--
-- Struktur dari tabel `kegiatan_harian`
--

CREATE TABLE `kegiatan_harian` (
  `id` int(11) NOT NULL,
  `peserta_id` int(11) NOT NULL,
  `tanggal` date NOT NULL,
  `deskripsi` text NOT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp()
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data untuk tabel `kegiatan_harian`
--

INSERT INTO `kegiatan_harian` (`id`, `peserta_id`, `tanggal`, `deskripsi`, `created_at`) VALUES
(1, 1, '2026-10-21', 'mencoba publish web dengan hosting gratis', '2026-10-21 07:56:43'),
(2, 2, '2026-10-28', 'sasasasasasa', '2026-10-28 02:25:27'),
(3, 2, '2026-10-28', 'test', '2026-10-28 02:25:34'),
(4, 2, '2026-10-28', 'input', '2026-10-28 02:25:41');

-- --------------------------------------------------------

--
-- Struktur dari tabel `pegawai`
--

CREATE TABLE `pegawai` (
  `id` int(11) NOT NULL,
  `nama` varchar(150) NOT NULL,
  `jabatan` varchar(100) NOT NULL,
  `nip` varchar(30) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data untuk tabel `pegawai`
--

INSERT INTO `pegawai` (`id`, `nama`, `jabatan`, `nip`) VALUES
(1, 'Aulia Rahman S.E, M.Si', 'Kasubag Umum', '198610062006041008'),
(2, 'Abdul Razi S.Si', 'Kepala BPS', '197612291999011001'),
(3, 'Atika Surya Ananda SST', 'Mentor', '199104052014122001'),
(4, 'Chesilia Amora Jofipasi S.Stat.', 'Mentor', '199507222019032001'),
(5, 'Fitri Ananda S.Si', 'Mentor', '198612152009022005'),
(6, 'Fitria Febriana A.Md.Kom.', 'Mentor', '199702112024212002'),
(7, 'Lina Ferdianty Lubis SST', 'Mentor', '198002162002122005'),
(8, 'Masruqi Arrazy SST., M.M.', 'Mentor', '198701242009021003'),
(9, 'Riko Tri Utama SST', 'Mentor', '199408212018021001'),
(10, 'Selfia Ladiyance SST', 'Mentor', '198911242013112002'),
(11, 'Utari Azalika Rahmi SST', 'Mentor', '199111052014102001'),
(12, 'Yesi Ariyani S.Si', 'Mentor', '198804162014032005'),
(13, 'Zaky Imadudin Salam S.Tr.Stat.', 'Mentor', '199910112023021001'),
(14, 'Zuharon S.Kom', 'Mentor', '198901072025211050'),
(15, 'Afdhal Mubarak S.E', 'Mentor', '198410302011011016'),
(16, 'Dwithia Handriani SST', 'Mentor', '199007172014102001'),
(17, 'Easbi Ikhsan S.Tr.Stat.', 'Mentor', '199602182019011002'),
(18, 'Juli Asril', 'Mentor', '198707022025211044'),
(19, 'Mega Novita S.Sos', 'Mentor', '198508032005022001'),
(20, 'Nove Ira S.Psi.', 'Mentor', '197611092011012005'),
(21, 'Novicha Haris A.Md.Stat.', 'Mentor', '199911122023022002'),
(22, 'Rindy Primadini SST', 'Mentor', '199105192013112001'),
(23, 'Riza Gusti', 'Mentor', '198609272025212036'),
(24, 'Suciana Ramadhani A.Md', 'Mentor', '199104052025212061'),
(25, 'Zikri Hardinata S.Kom', 'Mentor', '198212162025211030');

-- --------------------------------------------------------

--
-- Struktur dari tabel `pengajuan`
--

CREATE TABLE `pengajuan` (
  `id` int(11) NOT NULL,
  `peserta_id` int(11) NOT NULL,
  `tanggal` date NOT NULL,
  `jenis` enum('absen_manual','izin','sakit') NOT NULL,
  `jam_masuk_diajukan` time DEFAULT NULL,
  `jam_pulang_diajukan` time DEFAULT NULL,
  `keterangan` text NOT NULL,
  `status_pengajuan` enum('menunggu','disetujui','ditolak') NOT NULL DEFAULT 'menunggu',
  `catatan_admin` text DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `diproses_at` timestamp NULL DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data untuk tabel `pengajuan`
--

INSERT INTO `pengajuan` (`id`, `peserta_id`, `tanggal`, `jenis`, `jam_masuk_diajukan`, `jam_pulang_diajukan`, `keterangan`, `status_pengajuan`, `catatan_admin`, `created_at`, `diproses_at`) VALUES
(1, 1, '2026-10-14', 'izin', NULL, NULL, 'testing izin', 'disetujui', NULL, '2026-10-21 07:57:41', '2026-10-21 07:58:40'),
(2, 1, '2026-10-15', 'izin', NULL, NULL, 'testing izin tolak', 'ditolak', 'testing tolak', '2026-10-21 07:58:01', '2026-10-21 08:00:21'),
(3, 1, '2026-10-16', 'sakit', NULL, NULL, 'testing sakit', 'disetujui', NULL, '2026-10-21 07:58:12', '2026-10-21 07:58:35');

-- --------------------------------------------------------

--
-- Struktur dari tabel `peserta`
--

CREATE TABLE `peserta` (
  `id` int(11) NOT NULL,
  `nama` varchar(100) NOT NULL,
  `nim` varchar(30) NOT NULL,
  `jurusan` varchar(100) NOT NULL,
  `asal_universitas` varchar(150) NOT NULL,
  `nama_mentor` varchar(100) NOT NULL,
  `nip_mentor` varchar(30) NOT NULL DEFAULT '',
  `foto` varchar(255) DEFAULT NULL,
  `tanggal_mulai` date NOT NULL,
  `tanggal_selesai` date NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp()
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data untuk tabel `peserta`
--

INSERT INTO `peserta` (`id`, `nama`, `nim`, `jurusan`, `asal_universitas`, `nama_mentor`, `nip_mentor`, `foto`, `tanggal_mulai`, `tanggal_selesai`, `username`, `password`, `created_at`) VALUES
(1, 'Muhammad Fakhri Ramadhan', '2923009', 'Informatika', 'UIN Sjech M. Djamil Djambek Bukittinggi', 'Riko Tri Utama SST', '199408212018021001', 'peserta_6ad70a37e1b03.png', '2026-10-01', '2026-10-31', 'fakhri', '$2y$12$N3kJcpwwGTNwaZFOxbezU.ZrWH4OMFkEQq7Tx9Sac1uHv9DRQO54.', '2026-10-20 06:29:13'),
(2, 'Sari Agustin', '9999999', 'Statistika', 'UNP', 'Masruqi Arrazy SST., M.M.', '198701242009021003', 'peserta_6ae15d63aa4ef.png', '2026-10-01', '2026-10-30', 'sari', '$2y$12$NrmUHZzEb8P4rk4teP4dl.JloD2baDLKoIbZUiL53BNJ.z5THt8ZW', '2026-10-28 02:23:14'),
(3, 'riko', '111111', '111111', '111111', 'Selfia Ladiyance SST', '198911242013112002', NULL, '2026-10-28', '2026-10-31', 'rikoriko', '$2y$12$cGVapFJSc0sMJ5pcUlHOmOjjpWyeL.vUgIsAlIh6AulUobGdru/N6', '2026-10-28 02:24:13'),
(4, 'riko1', 'aaaaaa', 'aaaaaa', 'aaaaaa', 'Lina Ferdianty Lubis SST', '198002162002122005', NULL, '2026-10-12', '2026-10-12', 'rikoriko1', '$2y$12$RZVvlj8NXrQHqaA9YpQCOur4WSgoMLitVM3e3jU8WbYaXAZ/mUhsu', '2026-10-28 02:26:07');

--
-- Indexes for dumped tables
--

--
-- Indeks untuk tabel `absensi`
--
ALTER TABLE `absensi`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `unique_absen_harian` (`peserta_id`,`tanggal`);

--
-- Indeks untuk tabel `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`);

--
-- Indeks untuk tabel `kegiatan_harian`
--
ALTER TABLE `kegiatan_harian`
  ADD PRIMARY KEY (`id`),
  ADD KEY `peserta_id` (`peserta_id`);

--
-- Indeks untuk tabel `pegawai`
--
ALTER TABLE `pegawai`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `pengajuan`
--
ALTER TABLE `pengajuan`
  ADD PRIMARY KEY (`id`),
  ADD KEY `peserta_id` (`peserta_id`);

--
-- Indeks untuk tabel `peserta`
--
ALTER TABLE `peserta`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`);

--
-- AUTO_INCREMENT untuk tabel yang dibuang
--

--
-- AUTO_INCREMENT untuk tabel `absensi`
--
ALTER TABLE `absensi`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT untuk tabel `admin`
--
ALTER TABLE `admin`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT untuk tabel `kegiatan_harian`
--
ALTER TABLE `kegiatan_harian`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT untuk tabel `pegawai`
--
ALTER TABLE `pegawai`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=26;

--
-- AUTO_INCREMENT untuk tabel `pengajuan`
--
ALTER TABLE `pengajuan`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT untuk tabel `peserta`
--
ALTER TABLE `peserta`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
